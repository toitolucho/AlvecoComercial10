﻿namespace SAlvecoComercial10.Formularios.GestionSistema
{
    partial class FGeografico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FGeografico));
            this.tPLugares = new System.Windows.Forms.TabPage();
            this.bBuscarLugar = new System.Windows.Forms.Button();
            this.imgListGeografico = new System.Windows.Forms.ImageList(this.components);
            this.SalirL = new System.Windows.Forms.Button();
            this.bCancelarL = new System.Windows.Forms.Button();
            this.bAceptarL = new System.Windows.Forms.Button();
            this.bEliminarL = new System.Windows.Forms.Button();
            this.bEditarL = new System.Windows.Forms.Button();
            this.bNuevoL = new System.Windows.Forms.Button();
            this.tBNombreLugar = new System.Windows.Forms.TextBox();
            this.tBCodigoLugar = new System.Windows.Forms.TextBox();
            this.cBNombreProvinciaL = new System.Windows.Forms.ComboBox();
            this.cBNombreDepartamentoL = new System.Windows.Forms.ComboBox();
            this.cBNombrePaisL = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tPProvincias = new System.Windows.Forms.TabPage();
            this.bBuscarProv = new System.Windows.Forms.Button();
            this.SalirP = new System.Windows.Forms.Button();
            this.bCancelarP = new System.Windows.Forms.Button();
            this.bAceptarP = new System.Windows.Forms.Button();
            this.bEliminarP = new System.Windows.Forms.Button();
            this.bEditarP = new System.Windows.Forms.Button();
            this.bNuevoP = new System.Windows.Forms.Button();
            this.tBNombreProvincia = new System.Windows.Forms.TextBox();
            this.tBCodigoProvincia = new System.Windows.Forms.TextBox();
            this.cBDepartamentoN = new System.Windows.Forms.ComboBox();
            this.cBNombrePaisP = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tPDepartamentos = new System.Windows.Forms.TabPage();
            this.bBuscarDep = new System.Windows.Forms.Button();
            this.SalirD = new System.Windows.Forms.Button();
            this.bCancelarD = new System.Windows.Forms.Button();
            this.bNuevoD = new System.Windows.Forms.Button();
            this.bEliminarD = new System.Windows.Forms.Button();
            this.bEditarD = new System.Windows.Forms.Button();
            this.bAceptarD = new System.Windows.Forms.Button();
            this.tBNombreDepartamento = new System.Windows.Forms.TextBox();
            this.tBCodigoDepartamento = new System.Windows.Forms.TextBox();
            this.cBNombrePais = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tPPaises = new System.Windows.Forms.TabPage();
            this.bBuscarPais = new System.Windows.Forms.Button();
            this.Salir = new System.Windows.Forms.Button();
            this.bCancelar = new System.Windows.Forms.Button();
            this.bEliminar = new System.Windows.Forms.Button();
            this.bAceptar = new System.Windows.Forms.Button();
            this.bEditar = new System.Windows.Forms.Button();
            this.bNuevo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tBNacionalidad = new System.Windows.Forms.TextBox();
            this.tBNombrePais = new System.Windows.Forms.TextBox();
            this.tBCodigoPais = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tPLugares.SuspendLayout();
            this.tPProvincias.SuspendLayout();
            this.tPDepartamentos.SuspendLayout();
            this.tPPaises.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tPLugares
            // 
            this.tPLugares.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tPLugares.Controls.Add(this.bBuscarLugar);
            this.tPLugares.Controls.Add(this.SalirL);
            this.tPLugares.Controls.Add(this.bCancelarL);
            this.tPLugares.Controls.Add(this.bAceptarL);
            this.tPLugares.Controls.Add(this.bEliminarL);
            this.tPLugares.Controls.Add(this.bEditarL);
            this.tPLugares.Controls.Add(this.bNuevoL);
            this.tPLugares.Controls.Add(this.tBNombreLugar);
            this.tPLugares.Controls.Add(this.tBCodigoLugar);
            this.tPLugares.Controls.Add(this.cBNombreProvinciaL);
            this.tPLugares.Controls.Add(this.cBNombreDepartamentoL);
            this.tPLugares.Controls.Add(this.cBNombrePaisL);
            this.tPLugares.Controls.Add(this.label19);
            this.tPLugares.Controls.Add(this.label18);
            this.tPLugares.Controls.Add(this.label17);
            this.tPLugares.Controls.Add(this.label16);
            this.tPLugares.Controls.Add(this.label15);
            this.tPLugares.Location = new System.Drawing.Point(4, 22);
            this.tPLugares.Name = "tPLugares";
            this.tPLugares.Padding = new System.Windows.Forms.Padding(3);
            this.tPLugares.Size = new System.Drawing.Size(482, 175);
            this.tPLugares.TabIndex = 3;
            this.tPLugares.Text = "Lugar Comunidad";
            // 
            // bBuscarLugar
            // 
            this.bBuscarLugar.BackColor = System.Drawing.Color.White;
            this.bBuscarLugar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bBuscarLugar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bBuscarLugar.Image = global::SAlvecoComercial10.Properties.Resources.FILEFIND;
            this.bBuscarLugar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bBuscarLugar.Location = new System.Drawing.Point(354, 139);
            this.bBuscarLugar.Name = "bBuscarLugar";
            this.bBuscarLugar.Size = new System.Drawing.Size(65, 29);
            this.bBuscarLugar.TabIndex = 10;
            this.bBuscarLugar.Text = "&Buscar";
            this.bBuscarLugar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBuscarLugar.UseVisualStyleBackColor = false;
            this.bBuscarLugar.Visible = false;
            this.bBuscarLugar.Click += new System.EventHandler(this.bBuscarLugar_Click);
            // 
            // imgListGeografico
            // 
            this.imgListGeografico.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListGeografico.ImageStream")));
            this.imgListGeografico.TransparentColor = System.Drawing.Color.Transparent;
            this.imgListGeografico.Images.SetKeyName(0, "Undo.ico");
            this.imgListGeografico.Images.SetKeyName(1, "Edit.ico");
            this.imgListGeografico.Images.SetKeyName(2, "Save.ico");
            this.imgListGeografico.Images.SetKeyName(3, "Symbol-Add.ico");
            this.imgListGeografico.Images.SetKeyName(4, "Symbol-Check.ico");
            this.imgListGeografico.Images.SetKeyName(5, "Symbol-Delete.ico");
            this.imgListGeografico.Images.SetKeyName(6, "delete.ico");
            this.imgListGeografico.Images.SetKeyName(7, "Generic.ico");
            this.imgListGeografico.Images.SetKeyName(8, "card.ico");
            this.imgListGeografico.Images.SetKeyName(9, "search.ico");
            // 
            // SalirL
            // 
            this.SalirL.BackColor = System.Drawing.Color.White;
            this.SalirL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SalirL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SalirL.Image = global::SAlvecoComercial10.Properties.Resources.button_cancel;
            this.SalirL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalirL.Location = new System.Drawing.Point(423, 139);
            this.SalirL.Name = "SalirL";
            this.SalirL.Size = new System.Drawing.Size(54, 29);
            this.SalirL.TabIndex = 11;
            this.SalirL.Text = "&Salir";
            this.SalirL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SalirL.UseVisualStyleBackColor = false;
            this.SalirL.Click += new System.EventHandler(this.SalirL_Click);
            // 
            // bCancelarL
            // 
            this.bCancelarL.BackColor = System.Drawing.Color.White;
            this.bCancelarL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bCancelarL.Enabled = false;
            this.bCancelarL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bCancelarL.Image = global::SAlvecoComercial10.Properties.Resources.arrow_rotate_clockwise;
            this.bCancelarL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCancelarL.Location = new System.Drawing.Point(279, 139);
            this.bCancelarL.Name = "bCancelarL";
            this.bCancelarL.Size = new System.Drawing.Size(71, 29);
            this.bCancelarL.TabIndex = 9;
            this.bCancelarL.Text = "&Cancelar";
            this.bCancelarL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bCancelarL.UseVisualStyleBackColor = false;
            this.bCancelarL.Click += new System.EventHandler(this.bCancelarL_Click);
            // 
            // bAceptarL
            // 
            this.bAceptarL.BackColor = System.Drawing.Color.White;
            this.bAceptarL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAceptarL.Enabled = false;
            this.bAceptarL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bAceptarL.Image = global::SAlvecoComercial10.Properties.Resources.accept;
            this.bAceptarL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bAceptarL.Location = new System.Drawing.Point(209, 139);
            this.bAceptarL.Name = "bAceptarL";
            this.bAceptarL.Size = new System.Drawing.Size(65, 29);
            this.bAceptarL.TabIndex = 8;
            this.bAceptarL.Text = "&Aceptar";
            this.bAceptarL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bAceptarL.UseVisualStyleBackColor = false;
            this.bAceptarL.Click += new System.EventHandler(this.bAceptarL_Click);
            // 
            // bEliminarL
            // 
            this.bEliminarL.BackColor = System.Drawing.Color.White;
            this.bEliminarL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEliminarL.Enabled = false;
            this.bEliminarL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEliminarL.Image = global::SAlvecoComercial10.Properties.Resources.cancel1;
            this.bEliminarL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEliminarL.Location = new System.Drawing.Point(140, 139);
            this.bEliminarL.Name = "bEliminarL";
            this.bEliminarL.Size = new System.Drawing.Size(65, 29);
            this.bEliminarL.TabIndex = 7;
            this.bEliminarL.Text = "&Eliminar";
            this.bEliminarL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEliminarL.UseVisualStyleBackColor = false;
            this.bEliminarL.Click += new System.EventHandler(this.bEliminarL_Click);
            // 
            // bEditarL
            // 
            this.bEditarL.BackColor = System.Drawing.Color.White;
            this.bEditarL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEditarL.Enabled = false;
            this.bEditarL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEditarL.Image = global::SAlvecoComercial10.Properties.Resources.pencil1;
            this.bEditarL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEditarL.Location = new System.Drawing.Point(72, 139);
            this.bEditarL.Name = "bEditarL";
            this.bEditarL.Size = new System.Drawing.Size(64, 29);
            this.bEditarL.TabIndex = 6;
            this.bEditarL.Text = "&Editar";
            this.bEditarL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEditarL.UseVisualStyleBackColor = false;
            this.bEditarL.Click += new System.EventHandler(this.bEditarL_Click);
            // 
            // bNuevoL
            // 
            this.bNuevoL.BackColor = System.Drawing.Color.White;
            this.bNuevoL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bNuevoL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bNuevoL.Image = global::SAlvecoComercial10.Properties.Resources.add1;
            this.bNuevoL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bNuevoL.Location = new System.Drawing.Point(7, 139);
            this.bNuevoL.Name = "bNuevoL";
            this.bNuevoL.Size = new System.Drawing.Size(61, 29);
            this.bNuevoL.TabIndex = 5;
            this.bNuevoL.Text = "&Nuevo";
            this.bNuevoL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bNuevoL.UseVisualStyleBackColor = false;
            this.bNuevoL.Click += new System.EventHandler(this.bNuevoL_Click);
            // 
            // tBNombreLugar
            // 
            this.tBNombreLugar.Location = new System.Drawing.Point(122, 100);
            this.tBNombreLugar.Name = "tBNombreLugar";
            this.tBNombreLugar.ReadOnly = true;
            this.tBNombreLugar.Size = new System.Drawing.Size(300, 20);
            this.tBNombreLugar.TabIndex = 4;
            // 
            // tBCodigoLugar
            // 
            this.tBCodigoLugar.Location = new System.Drawing.Point(122, 74);
            this.tBCodigoLugar.Name = "tBCodigoLugar";
            this.tBCodigoLugar.ReadOnly = true;
            this.tBCodigoLugar.Size = new System.Drawing.Size(30, 20);
            this.tBCodigoLugar.TabIndex = 3;
            this.tBCodigoLugar.TextChanged += new System.EventHandler(this.tBCodigoLugar_TextChanged);
            // 
            // cBNombreProvinciaL
            // 
            this.cBNombreProvinciaL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNombreProvinciaL.Enabled = false;
            this.cBNombreProvinciaL.FormattingEnabled = true;
            this.cBNombreProvinciaL.Location = new System.Drawing.Point(122, 50);
            this.cBNombreProvinciaL.Name = "cBNombreProvinciaL";
            this.cBNombreProvinciaL.Size = new System.Drawing.Size(300, 21);
            this.cBNombreProvinciaL.TabIndex = 2;
            this.cBNombreProvinciaL.SelectedIndexChanged += new System.EventHandler(this.cBNombreProvinciaL_SelectedIndexChanged);
            // 
            // cBNombreDepartamentoL
            // 
            this.cBNombreDepartamentoL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNombreDepartamentoL.Enabled = false;
            this.cBNombreDepartamentoL.FormattingEnabled = true;
            this.cBNombreDepartamentoL.Location = new System.Drawing.Point(122, 28);
            this.cBNombreDepartamentoL.Name = "cBNombreDepartamentoL";
            this.cBNombreDepartamentoL.Size = new System.Drawing.Size(300, 21);
            this.cBNombreDepartamentoL.TabIndex = 1;
            this.cBNombreDepartamentoL.SelectedValueChanged += new System.EventHandler(this.cBNombreDepartamentoL_SelectedValueChanged);
            // 
            // cBNombrePaisL
            // 
            this.cBNombrePaisL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNombrePaisL.Enabled = false;
            this.cBNombrePaisL.FormattingEnabled = true;
            this.cBNombrePaisL.Location = new System.Drawing.Point(122, 5);
            this.cBNombrePaisL.Name = "cBNombrePaisL";
            this.cBNombrePaisL.Size = new System.Drawing.Size(300, 21);
            this.cBNombrePaisL.TabIndex = 0;
            this.cBNombrePaisL.SelectedValueChanged += new System.EventHandler(this.cBNombrePaisL_SelectedValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(42, 104);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Nombre Lugar";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(46, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Codigo Lugar";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(65, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "Provincia";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(42, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Departamento";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(89, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Pais";
            // 
            // tPProvincias
            // 
            this.tPProvincias.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tPProvincias.Controls.Add(this.bBuscarProv);
            this.tPProvincias.Controls.Add(this.SalirP);
            this.tPProvincias.Controls.Add(this.bCancelarP);
            this.tPProvincias.Controls.Add(this.bAceptarP);
            this.tPProvincias.Controls.Add(this.bEliminarP);
            this.tPProvincias.Controls.Add(this.bEditarP);
            this.tPProvincias.Controls.Add(this.bNuevoP);
            this.tPProvincias.Controls.Add(this.tBNombreProvincia);
            this.tPProvincias.Controls.Add(this.tBCodigoProvincia);
            this.tPProvincias.Controls.Add(this.cBDepartamentoN);
            this.tPProvincias.Controls.Add(this.cBNombrePaisP);
            this.tPProvincias.Controls.Add(this.label13);
            this.tPProvincias.Controls.Add(this.label12);
            this.tPProvincias.Controls.Add(this.label11);
            this.tPProvincias.Controls.Add(this.label10);
            this.tPProvincias.Location = new System.Drawing.Point(4, 22);
            this.tPProvincias.Name = "tPProvincias";
            this.tPProvincias.Padding = new System.Windows.Forms.Padding(3);
            this.tPProvincias.Size = new System.Drawing.Size(482, 175);
            this.tPProvincias.TabIndex = 2;
            this.tPProvincias.Text = "Provincia";
            // 
            // bBuscarProv
            // 
            this.bBuscarProv.BackColor = System.Drawing.Color.White;
            this.bBuscarProv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bBuscarProv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bBuscarProv.Image = global::SAlvecoComercial10.Properties.Resources.FILEFIND;
            this.bBuscarProv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bBuscarProv.Location = new System.Drawing.Point(353, 139);
            this.bBuscarProv.Name = "bBuscarProv";
            this.bBuscarProv.Size = new System.Drawing.Size(65, 29);
            this.bBuscarProv.TabIndex = 9;
            this.bBuscarProv.Text = "&Buscar";
            this.bBuscarProv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBuscarProv.UseVisualStyleBackColor = false;
            this.bBuscarProv.Visible = false;
            this.bBuscarProv.Click += new System.EventHandler(this.bBuscarProv_Click);
            // 
            // SalirP
            // 
            this.SalirP.BackColor = System.Drawing.Color.White;
            this.SalirP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SalirP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SalirP.Image = global::SAlvecoComercial10.Properties.Resources.button_cancel;
            this.SalirP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalirP.Location = new System.Drawing.Point(422, 139);
            this.SalirP.Name = "SalirP";
            this.SalirP.Size = new System.Drawing.Size(56, 29);
            this.SalirP.TabIndex = 10;
            this.SalirP.Text = "&Salir";
            this.SalirP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SalirP.UseVisualStyleBackColor = false;
            this.SalirP.Click += new System.EventHandler(this.SalirP_Click);
            // 
            // bCancelarP
            // 
            this.bCancelarP.BackColor = System.Drawing.Color.White;
            this.bCancelarP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bCancelarP.Enabled = false;
            this.bCancelarP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bCancelarP.Image = global::SAlvecoComercial10.Properties.Resources.arrow_rotate_clockwise;
            this.bCancelarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCancelarP.Location = new System.Drawing.Point(278, 139);
            this.bCancelarP.Name = "bCancelarP";
            this.bCancelarP.Size = new System.Drawing.Size(71, 29);
            this.bCancelarP.TabIndex = 8;
            this.bCancelarP.Text = "&Cancelar";
            this.bCancelarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bCancelarP.UseVisualStyleBackColor = false;
            this.bCancelarP.Click += new System.EventHandler(this.bCancelarP_Click);
            // 
            // bAceptarP
            // 
            this.bAceptarP.BackColor = System.Drawing.Color.White;
            this.bAceptarP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAceptarP.Enabled = false;
            this.bAceptarP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bAceptarP.Image = global::SAlvecoComercial10.Properties.Resources.accept;
            this.bAceptarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bAceptarP.Location = new System.Drawing.Point(204, 139);
            this.bAceptarP.Name = "bAceptarP";
            this.bAceptarP.Size = new System.Drawing.Size(70, 29);
            this.bAceptarP.TabIndex = 7;
            this.bAceptarP.Text = "&Aceptar";
            this.bAceptarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bAceptarP.UseVisualStyleBackColor = false;
            this.bAceptarP.Click += new System.EventHandler(this.bAceptarP_Click);
            // 
            // bEliminarP
            // 
            this.bEliminarP.BackColor = System.Drawing.Color.White;
            this.bEliminarP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEliminarP.Enabled = false;
            this.bEliminarP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEliminarP.Image = global::SAlvecoComercial10.Properties.Resources.cancel1;
            this.bEliminarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEliminarP.Location = new System.Drawing.Point(135, 139);
            this.bEliminarP.Name = "bEliminarP";
            this.bEliminarP.Size = new System.Drawing.Size(65, 29);
            this.bEliminarP.TabIndex = 6;
            this.bEliminarP.Text = "&Eliminar";
            this.bEliminarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEliminarP.UseVisualStyleBackColor = false;
            this.bEliminarP.Click += new System.EventHandler(this.bEliminarP_Click);
            // 
            // bEditarP
            // 
            this.bEditarP.BackColor = System.Drawing.Color.White;
            this.bEditarP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEditarP.Enabled = false;
            this.bEditarP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEditarP.Image = global::SAlvecoComercial10.Properties.Resources.pencil1;
            this.bEditarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEditarP.Location = new System.Drawing.Point(72, 139);
            this.bEditarP.Name = "bEditarP";
            this.bEditarP.Size = new System.Drawing.Size(59, 29);
            this.bEditarP.TabIndex = 5;
            this.bEditarP.Text = "&Editar";
            this.bEditarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEditarP.UseVisualStyleBackColor = false;
            this.bEditarP.Click += new System.EventHandler(this.bEditarP_Click);
            // 
            // bNuevoP
            // 
            this.bNuevoP.BackColor = System.Drawing.Color.White;
            this.bNuevoP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bNuevoP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bNuevoP.Image = global::SAlvecoComercial10.Properties.Resources.add1;
            this.bNuevoP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bNuevoP.Location = new System.Drawing.Point(7, 139);
            this.bNuevoP.Name = "bNuevoP";
            this.bNuevoP.Size = new System.Drawing.Size(61, 29);
            this.bNuevoP.TabIndex = 4;
            this.bNuevoP.Text = "&Nuevo";
            this.bNuevoP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bNuevoP.UseVisualStyleBackColor = false;
            this.bNuevoP.Click += new System.EventHandler(this.bNuevoP_Click);
            // 
            // tBNombreProvincia
            // 
            this.tBNombreProvincia.Location = new System.Drawing.Point(131, 89);
            this.tBNombreProvincia.Name = "tBNombreProvincia";
            this.tBNombreProvincia.ReadOnly = true;
            this.tBNombreProvincia.Size = new System.Drawing.Size(300, 20);
            this.tBNombreProvincia.TabIndex = 3;
            // 
            // tBCodigoProvincia
            // 
            this.tBCodigoProvincia.Location = new System.Drawing.Point(131, 60);
            this.tBCodigoProvincia.Name = "tBCodigoProvincia";
            this.tBCodigoProvincia.ReadOnly = true;
            this.tBCodigoProvincia.Size = new System.Drawing.Size(30, 20);
            this.tBCodigoProvincia.TabIndex = 2;
            this.tBCodigoProvincia.TextChanged += new System.EventHandler(this.tBCodigoProvincia_TextChanged);
            // 
            // cBDepartamentoN
            // 
            this.cBDepartamentoN.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBDepartamentoN.Enabled = false;
            this.cBDepartamentoN.FormattingEnabled = true;
            this.cBDepartamentoN.Location = new System.Drawing.Point(131, 32);
            this.cBDepartamentoN.Name = "cBDepartamentoN";
            this.cBDepartamentoN.Size = new System.Drawing.Size(300, 21);
            this.cBDepartamentoN.TabIndex = 1;
            this.cBDepartamentoN.SelectedIndexChanged += new System.EventHandler(this.cBDepartamentoN_SelectedIndexChanged);
            // 
            // cBNombrePaisP
            // 
            this.cBNombrePaisP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNombrePaisP.Enabled = false;
            this.cBNombrePaisP.FormattingEnabled = true;
            this.cBNombrePaisP.Location = new System.Drawing.Point(131, 5);
            this.cBNombrePaisP.Name = "cBNombrePaisP";
            this.cBNombrePaisP.Size = new System.Drawing.Size(300, 21);
            this.cBNombrePaisP.TabIndex = 0;
            this.cBNombrePaisP.SelectedValueChanged += new System.EventHandler(this.cBNombrePaisP_SelectedValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Nombre Provincia";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 67);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Codigo Provincia";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(51, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Departamento";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(98, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Pais";
            // 
            // tPDepartamentos
            // 
            this.tPDepartamentos.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tPDepartamentos.Controls.Add(this.bBuscarDep);
            this.tPDepartamentos.Controls.Add(this.SalirD);
            this.tPDepartamentos.Controls.Add(this.bCancelarD);
            this.tPDepartamentos.Controls.Add(this.bNuevoD);
            this.tPDepartamentos.Controls.Add(this.bEliminarD);
            this.tPDepartamentos.Controls.Add(this.bEditarD);
            this.tPDepartamentos.Controls.Add(this.bAceptarD);
            this.tPDepartamentos.Controls.Add(this.tBNombreDepartamento);
            this.tPDepartamentos.Controls.Add(this.tBCodigoDepartamento);
            this.tPDepartamentos.Controls.Add(this.cBNombrePais);
            this.tPDepartamentos.Controls.Add(this.label8);
            this.tPDepartamentos.Controls.Add(this.label7);
            this.tPDepartamentos.Controls.Add(this.label6);
            this.tPDepartamentos.Location = new System.Drawing.Point(4, 22);
            this.tPDepartamentos.Name = "tPDepartamentos";
            this.tPDepartamentos.Padding = new System.Windows.Forms.Padding(3);
            this.tPDepartamentos.Size = new System.Drawing.Size(482, 175);
            this.tPDepartamentos.TabIndex = 1;
            this.tPDepartamentos.Text = "Departamento";
            // 
            // bBuscarDep
            // 
            this.bBuscarDep.BackColor = System.Drawing.Color.White;
            this.bBuscarDep.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bBuscarDep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bBuscarDep.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bBuscarDep.Image = global::SAlvecoComercial10.Properties.Resources.FILEFIND;
            this.bBuscarDep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bBuscarDep.Location = new System.Drawing.Point(350, 139);
            this.bBuscarDep.Name = "bBuscarDep";
            this.bBuscarDep.Size = new System.Drawing.Size(65, 29);
            this.bBuscarDep.TabIndex = 8;
            this.bBuscarDep.Text = "&Buscar";
            this.bBuscarDep.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBuscarDep.UseVisualStyleBackColor = false;
            this.bBuscarDep.Visible = false;
            this.bBuscarDep.Click += new System.EventHandler(this.bBuscarDep_Click);
            // 
            // SalirD
            // 
            this.SalirD.BackColor = System.Drawing.Color.White;
            this.SalirD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.SalirD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SalirD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SalirD.Image = global::SAlvecoComercial10.Properties.Resources.button_cancel;
            this.SalirD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalirD.Location = new System.Drawing.Point(419, 139);
            this.SalirD.Name = "SalirD";
            this.SalirD.Size = new System.Drawing.Size(58, 29);
            this.SalirD.TabIndex = 9;
            this.SalirD.Text = "&Salir";
            this.SalirD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SalirD.UseVisualStyleBackColor = false;
            this.SalirD.Click += new System.EventHandler(this.SalirD_Click);
            // 
            // bCancelarD
            // 
            this.bCancelarD.BackColor = System.Drawing.Color.White;
            this.bCancelarD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bCancelarD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bCancelarD.Enabled = false;
            this.bCancelarD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bCancelarD.Image = global::SAlvecoComercial10.Properties.Resources.arrow_rotate_clockwise;
            this.bCancelarD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCancelarD.Location = new System.Drawing.Point(270, 139);
            this.bCancelarD.Name = "bCancelarD";
            this.bCancelarD.Size = new System.Drawing.Size(76, 29);
            this.bCancelarD.TabIndex = 7;
            this.bCancelarD.Text = "&Cancelar";
            this.bCancelarD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bCancelarD.UseVisualStyleBackColor = false;
            this.bCancelarD.Click += new System.EventHandler(this.bCancelarD_Click);
            // 
            // bNuevoD
            // 
            this.bNuevoD.BackColor = System.Drawing.Color.White;
            this.bNuevoD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bNuevoD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bNuevoD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bNuevoD.Image = global::SAlvecoComercial10.Properties.Resources.add1;
            this.bNuevoD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bNuevoD.Location = new System.Drawing.Point(5, 139);
            this.bNuevoD.Name = "bNuevoD";
            this.bNuevoD.Size = new System.Drawing.Size(63, 29);
            this.bNuevoD.TabIndex = 3;
            this.bNuevoD.Text = "&Nuevo";
            this.bNuevoD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bNuevoD.UseVisualStyleBackColor = false;
            this.bNuevoD.Click += new System.EventHandler(this.bNuevoD_Click);
            // 
            // bEliminarD
            // 
            this.bEliminarD.BackColor = System.Drawing.Color.White;
            this.bEliminarD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bEliminarD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEliminarD.Enabled = false;
            this.bEliminarD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEliminarD.Image = global::SAlvecoComercial10.Properties.Resources.cancel1;
            this.bEliminarD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEliminarD.Location = new System.Drawing.Point(132, 139);
            this.bEliminarD.Name = "bEliminarD";
            this.bEliminarD.Size = new System.Drawing.Size(65, 29);
            this.bEliminarD.TabIndex = 5;
            this.bEliminarD.Text = "&Eliminar";
            this.bEliminarD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEliminarD.UseVisualStyleBackColor = false;
            this.bEliminarD.Click += new System.EventHandler(this.bEliminarD_Click);
            // 
            // bEditarD
            // 
            this.bEditarD.BackColor = System.Drawing.Color.White;
            this.bEditarD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bEditarD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEditarD.Enabled = false;
            this.bEditarD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEditarD.Image = global::SAlvecoComercial10.Properties.Resources.pencil1;
            this.bEditarD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEditarD.Location = new System.Drawing.Point(72, 139);
            this.bEditarD.Name = "bEditarD";
            this.bEditarD.Size = new System.Drawing.Size(56, 29);
            this.bEditarD.TabIndex = 4;
            this.bEditarD.Text = "&Editar";
            this.bEditarD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEditarD.UseVisualStyleBackColor = false;
            this.bEditarD.Click += new System.EventHandler(this.bEditarD_Click);
            // 
            // bAceptarD
            // 
            this.bAceptarD.BackColor = System.Drawing.Color.White;
            this.bAceptarD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bAceptarD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAceptarD.Enabled = false;
            this.bAceptarD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bAceptarD.Image = global::SAlvecoComercial10.Properties.Resources.accept;
            this.bAceptarD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bAceptarD.Location = new System.Drawing.Point(201, 139);
            this.bAceptarD.Name = "bAceptarD";
            this.bAceptarD.Size = new System.Drawing.Size(65, 29);
            this.bAceptarD.TabIndex = 6;
            this.bAceptarD.Text = "&Aceptar";
            this.bAceptarD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bAceptarD.UseVisualStyleBackColor = false;
            this.bAceptarD.Click += new System.EventHandler(this.bAceptarD_Click);
            // 
            // tBNombreDepartamento
            // 
            this.tBNombreDepartamento.Location = new System.Drawing.Point(142, 60);
            this.tBNombreDepartamento.Name = "tBNombreDepartamento";
            this.tBNombreDepartamento.ReadOnly = true;
            this.tBNombreDepartamento.Size = new System.Drawing.Size(300, 20);
            this.tBNombreDepartamento.TabIndex = 2;
            // 
            // tBCodigoDepartamento
            // 
            this.tBCodigoDepartamento.Location = new System.Drawing.Point(142, 32);
            this.tBCodigoDepartamento.Name = "tBCodigoDepartamento";
            this.tBCodigoDepartamento.ReadOnly = true;
            this.tBCodigoDepartamento.Size = new System.Drawing.Size(30, 20);
            this.tBCodigoDepartamento.TabIndex = 1;
            this.tBCodigoDepartamento.TextChanged += new System.EventHandler(this.tBCodigoDepartamento_TextChanged);
            // 
            // cBNombrePais
            // 
            this.cBNombrePais.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNombrePais.Enabled = false;
            this.cBNombrePais.FormattingEnabled = true;
            this.cBNombrePais.Location = new System.Drawing.Point(142, 5);
            this.cBNombrePais.Name = "cBNombrePais";
            this.cBNombrePais.Size = new System.Drawing.Size(300, 21);
            this.cBNombrePais.TabIndex = 0;
            this.cBNombrePais.SelectedIndexChanged += new System.EventHandler(this.cBNombrePais_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 67);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Nombre Departamento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Codigo Departamento";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(109, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Pais";
            // 
            // tPPaises
            // 
            this.tPPaises.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tPPaises.Controls.Add(this.bBuscarPais);
            this.tPPaises.Controls.Add(this.Salir);
            this.tPPaises.Controls.Add(this.bCancelar);
            this.tPPaises.Controls.Add(this.bEliminar);
            this.tPPaises.Controls.Add(this.bAceptar);
            this.tPPaises.Controls.Add(this.bEditar);
            this.tPPaises.Controls.Add(this.bNuevo);
            this.tPPaises.Controls.Add(this.label3);
            this.tPPaises.Controls.Add(this.label2);
            this.tPPaises.Controls.Add(this.label1);
            this.tPPaises.Controls.Add(this.tBNacionalidad);
            this.tPPaises.Controls.Add(this.tBNombrePais);
            this.tPPaises.Controls.Add(this.tBCodigoPais);
            this.tPPaises.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tPPaises.Location = new System.Drawing.Point(4, 22);
            this.tPPaises.Name = "tPPaises";
            this.tPPaises.Padding = new System.Windows.Forms.Padding(3);
            this.tPPaises.Size = new System.Drawing.Size(482, 175);
            this.tPPaises.TabIndex = 0;
            this.tPPaises.Text = "Pais";
            // 
            // bBuscarPais
            // 
            this.bBuscarPais.AutoEllipsis = true;
            this.bBuscarPais.BackColor = System.Drawing.Color.White;
            this.bBuscarPais.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bBuscarPais.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bBuscarPais.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bBuscarPais.ImageKey = "search.ico";
            this.bBuscarPais.Location = new System.Drawing.Point(346, 140);
            this.bBuscarPais.Name = "bBuscarPais";
            this.bBuscarPais.Size = new System.Drawing.Size(64, 29);
            this.bBuscarPais.TabIndex = 8;
            this.bBuscarPais.Text = "&Buscar";
            this.bBuscarPais.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBuscarPais.UseVisualStyleBackColor = false;
            this.bBuscarPais.Visible = false;
            this.bBuscarPais.Click += new System.EventHandler(this.bBuscarPais_Click);
            // 
            // Salir
            // 
            this.Salir.AutoEllipsis = true;
            this.Salir.BackColor = System.Drawing.Color.White;
            this.Salir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Salir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Salir.Image = global::SAlvecoComercial10.Properties.Resources.button_cancel;
            this.Salir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Salir.Location = new System.Drawing.Point(414, 140);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(60, 29);
            this.Salir.TabIndex = 9;
            this.Salir.Text = "&Salir   ";
            this.Salir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Salir.UseVisualStyleBackColor = false;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // bCancelar
            // 
            this.bCancelar.AutoEllipsis = true;
            this.bCancelar.BackColor = System.Drawing.Color.White;
            this.bCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bCancelar.Enabled = false;
            this.bCancelar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bCancelar.Image = global::SAlvecoComercial10.Properties.Resources.arrow_rotate_clockwise;
            this.bCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCancelar.Location = new System.Drawing.Point(274, 140);
            this.bCancelar.Name = "bCancelar";
            this.bCancelar.Size = new System.Drawing.Size(68, 29);
            this.bCancelar.TabIndex = 7;
            this.bCancelar.Text = "&Cancelar";
            this.bCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bCancelar.UseVisualStyleBackColor = false;
            this.bCancelar.Click += new System.EventHandler(this.bCancelar_Click);
            // 
            // bEliminar
            // 
            this.bEliminar.AutoEllipsis = true;
            this.bEliminar.BackColor = System.Drawing.Color.White;
            this.bEliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEliminar.Enabled = false;
            this.bEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bEliminar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEliminar.Image = global::SAlvecoComercial10.Properties.Resources.cancel1;
            this.bEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEliminar.Location = new System.Drawing.Point(135, 140);
            this.bEliminar.Name = "bEliminar";
            this.bEliminar.Size = new System.Drawing.Size(65, 29);
            this.bEliminar.TabIndex = 5;
            this.bEliminar.Text = "&Eliminar\r\n";
            this.bEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEliminar.UseVisualStyleBackColor = false;
            this.bEliminar.Click += new System.EventHandler(this.bEliminar_Click);
            // 
            // bAceptar
            // 
            this.bAceptar.AutoEllipsis = true;
            this.bAceptar.BackColor = System.Drawing.Color.White;
            this.bAceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAceptar.Enabled = false;
            this.bAceptar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bAceptar.Image = global::SAlvecoComercial10.Properties.Resources.accept;
            this.bAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bAceptar.Location = new System.Drawing.Point(204, 140);
            this.bAceptar.Name = "bAceptar";
            this.bAceptar.Size = new System.Drawing.Size(66, 29);
            this.bAceptar.TabIndex = 6;
            this.bAceptar.Text = "&Aceptar";
            this.bAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bAceptar.UseVisualStyleBackColor = false;
            this.bAceptar.Click += new System.EventHandler(this.bAceptar_Click);
            // 
            // bEditar
            // 
            this.bEditar.AutoEllipsis = true;
            this.bEditar.BackColor = System.Drawing.Color.White;
            this.bEditar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEditar.Enabled = false;
            this.bEditar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bEditar.Image = global::SAlvecoComercial10.Properties.Resources.pencil1;
            this.bEditar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEditar.Location = new System.Drawing.Point(71, 140);
            this.bEditar.Name = "bEditar";
            this.bEditar.Size = new System.Drawing.Size(60, 29);
            this.bEditar.TabIndex = 4;
            this.bEditar.Text = "&Editar";
            this.bEditar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEditar.UseVisualStyleBackColor = false;
            this.bEditar.Click += new System.EventHandler(this.bEditar_Click);
            // 
            // bNuevo
            // 
            this.bNuevo.AutoEllipsis = true;
            this.bNuevo.BackColor = System.Drawing.Color.White;
            this.bNuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bNuevo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bNuevo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bNuevo.Image = global::SAlvecoComercial10.Properties.Resources.add1;
            this.bNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bNuevo.Location = new System.Drawing.Point(3, 140);
            this.bNuevo.Name = "bNuevo";
            this.bNuevo.Size = new System.Drawing.Size(64, 29);
            this.bNuevo.TabIndex = 3;
            this.bNuevo.Text = "&Nuevo ";
            this.bNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bNuevo.UseVisualStyleBackColor = false;
            this.bNuevo.Click += new System.EventHandler(this.bNuevo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nacionalidad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nombre Pais";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Codigo Pais";
            // 
            // tBNacionalidad
            // 
            this.tBNacionalidad.Location = new System.Drawing.Point(151, 62);
            this.tBNacionalidad.Name = "tBNacionalidad";
            this.tBNacionalidad.ReadOnly = true;
            this.tBNacionalidad.Size = new System.Drawing.Size(239, 20);
            this.tBNacionalidad.TabIndex = 2;
            // 
            // tBNombrePais
            // 
            this.tBNombrePais.Location = new System.Drawing.Point(151, 36);
            this.tBNombrePais.Name = "tBNombrePais";
            this.tBNombrePais.ReadOnly = true;
            this.tBNombrePais.Size = new System.Drawing.Size(239, 20);
            this.tBNombrePais.TabIndex = 1;
            // 
            // tBCodigoPais
            // 
            this.tBCodigoPais.Location = new System.Drawing.Point(151, 9);
            this.tBCodigoPais.Name = "tBCodigoPais";
            this.tBCodigoPais.ReadOnly = true;
            this.tBCodigoPais.Size = new System.Drawing.Size(30, 20);
            this.tBCodigoPais.TabIndex = 0;
            this.tBCodigoPais.TextChanged += new System.EventHandler(this.tBCodigoPais_TextChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tPPaises);
            this.tabControl1.Controls.Add(this.tPDepartamentos);
            this.tabControl1.Controls.Add(this.tPProvincias);
            this.tabControl1.Controls.Add(this.tPLugares);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(490, 201);
            this.tabControl1.TabIndex = 0;
            // 
            // FGeografico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(490, 201);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FGeografico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configuración Geográfica";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FGeografico_Load);
            this.tPLugares.ResumeLayout(false);
            this.tPLugares.PerformLayout();
            this.tPProvincias.ResumeLayout(false);
            this.tPProvincias.PerformLayout();
            this.tPDepartamentos.ResumeLayout(false);
            this.tPDepartamentos.PerformLayout();
            this.tPPaises.ResumeLayout(false);
            this.tPPaises.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tPPaises;
        private System.Windows.Forms.Button bBuscarPais;
        private System.Windows.Forms.Button Salir;
        private System.Windows.Forms.Button bCancelar;
        private System.Windows.Forms.Button bEliminar;
        private System.Windows.Forms.Button bAceptar;
        private System.Windows.Forms.Button bEditar;
        private System.Windows.Forms.Button bNuevo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBNacionalidad;
        private System.Windows.Forms.TextBox tBNombrePais;
        private System.Windows.Forms.TextBox tBCodigoPais;
        private System.Windows.Forms.TabPage tPDepartamentos;
        private System.Windows.Forms.TextBox tBNombreDepartamento;
        private System.Windows.Forms.TextBox tBCodigoDepartamento;
        private System.Windows.Forms.ComboBox cBNombrePais;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tPProvincias;
        private System.Windows.Forms.Button bBuscarProv;
        private System.Windows.Forms.Button SalirP;
        private System.Windows.Forms.Button bCancelarP;
        private System.Windows.Forms.Button bAceptarP;
        private System.Windows.Forms.Button bEliminarP;
        private System.Windows.Forms.Button bEditarP;
        private System.Windows.Forms.Button bNuevoP;
        private System.Windows.Forms.TextBox tBNombreProvincia;
        private System.Windows.Forms.TextBox tBCodigoProvincia;
        private System.Windows.Forms.ComboBox cBDepartamentoN;
        private System.Windows.Forms.ComboBox cBNombrePaisP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tPLugares;
        private System.Windows.Forms.Button bBuscarLugar;
        private System.Windows.Forms.Button SalirL;
        private System.Windows.Forms.Button bCancelarL;
        private System.Windows.Forms.Button bAceptarL;
        private System.Windows.Forms.Button bEliminarL;
        private System.Windows.Forms.Button bEditarL;
        private System.Windows.Forms.Button bNuevoL;
        private System.Windows.Forms.TextBox tBNombreLugar;
        private System.Windows.Forms.TextBox tBCodigoLugar;
        private System.Windows.Forms.ComboBox cBNombreProvinciaL;
        private System.Windows.Forms.ComboBox cBNombreDepartamentoL;
        private System.Windows.Forms.ComboBox cBNombrePaisL;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button bBuscarDep;
        private System.Windows.Forms.Button SalirD;
        private System.Windows.Forms.Button bCancelarD;
        private System.Windows.Forms.Button bNuevoD;
        private System.Windows.Forms.Button bEliminarD;
        private System.Windows.Forms.Button bEditarD;
        private System.Windows.Forms.Button bAceptarD;
        private System.Windows.Forms.ImageList imgListGeografico;
    }
}