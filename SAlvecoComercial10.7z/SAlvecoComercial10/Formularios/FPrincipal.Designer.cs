﻿namespace SAlvecoComercial10.Formularios
{
    partial class FPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sSPrincipal = new System.Windows.Forms.StatusStrip();
            this.tsLblNombreServidor = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblNumeroAlmacen = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionBDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiaDeSeguridadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaurarCopiaDeSeguridadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.almacenesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cambiarContraseñaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.cambiarDeAlmacenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirDelSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestiónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.proveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripSeparator();
            this.personasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.herramientasGestiónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripSeparator();
            this.administradorDeComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.cuentasPorPagarPorComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripSeparator();
            this.devoluciónDeComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administradorDeDevolucionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeVentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.administradorVentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripSeparator();
            this.cuentasPorCobrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripSeparator();
            this.devolucionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administradorDeDevolucionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.administradorCuentasPorPagarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.administradorCuentasPorCobrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripSeparator();
            this.transferenciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeTransferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administradorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.unidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marcasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.procedenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.provinciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lugaresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripSeparator();
            this.administracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripSeparator();
            this.conceptosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripSeparator();
            this.movilidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movilidadesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposMovilidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kardexDeProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
            this.movimientoDeAlmacenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
            this.otroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.stockMinimoDeProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripSeparator();
            this.comprasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.productosEnEsperaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripSeparator();
            this.listaEnRangoDeFechasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoPorTiposProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoPorProveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoPorProveedorYTiposProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoPorUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumenMovimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripSeparator();
            this.cuentasPorPagarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripSeparator();
            this.ventasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoEnRangoDeFechasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoPorTiposProductosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoPorClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoPorClientesYTiposProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripSeparator();
            this.distribucionDeProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distribucionDeProductosPorClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoPorUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumenMovimientoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripSeparator();
            this.cuentasPorCobrarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripSeparator();
            this.movimientoMonetarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porDistribuidorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripSeparator();
            this.tiposDeProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripSeparator();
            this.devolucionesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripSeparator();
            this.bitacoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sSPrincipal.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sSPrincipal
            // 
            this.sSPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblNombreServidor,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.tslblNumeroAlmacen});
            this.sSPrincipal.Location = new System.Drawing.Point(0, 540);
            this.sSPrincipal.Name = "sSPrincipal";
            this.sSPrincipal.Size = new System.Drawing.Size(771, 22);
            this.sSPrincipal.TabIndex = 2;
            this.sSPrincipal.Text = "statusStrip1";
            // 
            // tsLblNombreServidor
            // 
            this.tsLblNombreServidor.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsLblNombreServidor.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.tsLblNombreServidor.Name = "tsLblNombreServidor";
            this.tsLblNombreServidor.Size = new System.Drawing.Size(58, 17);
            this.tsLblNombreServidor.Text = "Servidor: ";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(86, 17);
            this.toolStripStatusLabel2.Text = "Base de datos: ";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(89, 17);
            this.toolStripStatusLabel3.Text = "Código usuario: ";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel4.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(54, 17);
            this.toolStripStatusLabel4.Text = "Usuario: ";
            // 
            // tslblNumeroAlmacen
            // 
            this.tslblNumeroAlmacen.Name = "tslblNumeroAlmacen";
            this.tslblNumeroAlmacen.Size = new System.Drawing.Size(74, 17);
            this.tslblNumeroAlmacen.Text = "Nro Almacen :";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(771, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.gestiónToolStripMenuItem,
            this.herramientasGestiónToolStripMenuItem,
            this.toolStripMenuItem37,
            this.configuraciónToolStripMenuItem,
            this.reportesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(771, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionBDToolStripMenuItem,
            this.administraciónToolStripMenuItem,
            this.toolStripMenuItem1,
            this.cambiarContraseñaToolStripMenuItem,
            this.toolStripMenuItem2,
            this.cambiarDeAlmacenToolStripMenuItem,
            this.salirDelSistemaToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.archivoToolStripMenuItem.Text = "&Archivo";
            // 
            // gestionBDToolStripMenuItem
            // 
            this.gestionBDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiaDeSeguridadToolStripMenuItem,
            this.restaurarCopiaDeSeguridadToolStripMenuItem});
            this.gestionBDToolStripMenuItem.Name = "gestionBDToolStripMenuItem";
            this.gestionBDToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.gestionBDToolStripMenuItem.Text = "Gestion de &Base de Datos";
            // 
            // copiaDeSeguridadToolStripMenuItem
            // 
            this.copiaDeSeguridadToolStripMenuItem.Name = "copiaDeSeguridadToolStripMenuItem";
            this.copiaDeSeguridadToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.copiaDeSeguridadToolStripMenuItem.Text = "Copia de Seguridad";
            this.copiaDeSeguridadToolStripMenuItem.Click += new System.EventHandler(this.copiaDeSeguridadToolStripMenuItem_Click);
            // 
            // restaurarCopiaDeSeguridadToolStripMenuItem
            // 
            this.restaurarCopiaDeSeguridadToolStripMenuItem.Name = "restaurarCopiaDeSeguridadToolStripMenuItem";
            this.restaurarCopiaDeSeguridadToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.restaurarCopiaDeSeguridadToolStripMenuItem.Text = "Restaurar Copia de Seguridad";
            this.restaurarCopiaDeSeguridadToolStripMenuItem.Click += new System.EventHandler(this.restaurarCopiaDeSeguridadToolStripMenuItem_Click);
            // 
            // administraciónToolStripMenuItem
            // 
            this.administraciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuariosToolStripMenuItem,
            this.almacenesToolStripMenuItem});
            this.administraciónToolStripMenuItem.Name = "administraciónToolStripMenuItem";
            this.administraciónToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.administraciónToolStripMenuItem.Text = "A&dministración";
            // 
            // usuariosToolStripMenuItem
            // 
            this.usuariosToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.businessman;
            this.usuariosToolStripMenuItem.Name = "usuariosToolStripMenuItem";
            this.usuariosToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.usuariosToolStripMenuItem.Text = "Usuario&s";
            this.usuariosToolStripMenuItem.Click += new System.EventHandler(this.usuariosToolStripMenuItem_Click);
            // 
            // almacenesToolStripMenuItem
            // 
            this.almacenesToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.Factory;
            this.almacenesToolStripMenuItem.Name = "almacenesToolStripMenuItem";
            this.almacenesToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.almacenesToolStripMenuItem.Text = "A&lmacenes";
            this.almacenesToolStripMenuItem.Click += new System.EventHandler(this.almacenesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(205, 6);
            // 
            // cambiarContraseñaToolStripMenuItem
            // 
            this.cambiarContraseñaToolStripMenuItem.Name = "cambiarContraseñaToolStripMenuItem";
            this.cambiarContraseñaToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.cambiarContraseñaToolStripMenuItem.Text = "Cambiar Contraseña";
            this.cambiarContraseñaToolStripMenuItem.Click += new System.EventHandler(this.cambiarContraseñaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(205, 6);
            // 
            // cambiarDeAlmacenToolStripMenuItem
            // 
            this.cambiarDeAlmacenToolStripMenuItem.Name = "cambiarDeAlmacenToolStripMenuItem";
            this.cambiarDeAlmacenToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.cambiarDeAlmacenToolStripMenuItem.Text = "Cambiar de Almacen";
            this.cambiarDeAlmacenToolStripMenuItem.Click += new System.EventHandler(this.cambiarDeAlmacenToolStripMenuItem_Click);
            // 
            // salirDelSistemaToolStripMenuItem
            // 
            this.salirDelSistemaToolStripMenuItem.Name = "salirDelSistemaToolStripMenuItem";
            this.salirDelSistemaToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.salirDelSistemaToolStripMenuItem.Text = "Salir del Sistema";
            this.salirDelSistemaToolStripMenuItem.Click += new System.EventHandler(this.salirDelSistemaToolStripMenuItem_Click);
            // 
            // gestiónToolStripMenuItem
            // 
            this.gestiónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosToolStripMenuItem,
            this.toolStripMenuItem3,
            this.clientesToolStripMenuItem,
            this.toolStripMenuItem4,
            this.proveedoresToolStripMenuItem,
            this.toolStripMenuItem28,
            this.personasToolStripMenuItem});
            this.gestiónToolStripMenuItem.Name = "gestiónToolStripMenuItem";
            this.gestiónToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.gestiónToolStripMenuItem.Text = "&Gestión de Datos";
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.productosToolStripMenuItem.Text = "&Productos";
            this.productosToolStripMenuItem.Click += new System.EventHandler(this.productosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(149, 6);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.kdmconfig;
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.clientesToolStripMenuItem.Text = "&Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(149, 6);
            // 
            // proveedoresToolStripMenuItem
            // 
            this.proveedoresToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.Untitled__799_;
            this.proveedoresToolStripMenuItem.Name = "proveedoresToolStripMenuItem";
            this.proveedoresToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.proveedoresToolStripMenuItem.Text = "&Proveedores";
            this.proveedoresToolStripMenuItem.Click += new System.EventHandler(this.proveedoresToolStripMenuItem_Click);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(149, 6);
            // 
            // personasToolStripMenuItem
            // 
            this.personasToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.kdmconfig;
            this.personasToolStripMenuItem.Name = "personasToolStripMenuItem";
            this.personasToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.personasToolStripMenuItem.Text = "P&ersonal";
            this.personasToolStripMenuItem.Click += new System.EventHandler(this.personasToolStripMenuItem_Click);
            // 
            // herramientasGestiónToolStripMenuItem
            // 
            this.herramientasGestiónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comprasToolStripMenuItem,
            this.toolStripMenuItem6,
            this.ventasToolStripMenuItem,
            this.toolStripMenuItem8,
            this.administradorCuentasPorPagarToolStripMenuItem,
            this.toolStripMenuItem9,
            this.administradorCuentasPorCobrarToolStripMenuItem,
            this.toolStripMenuItem20,
            this.transferenciasToolStripMenuItem});
            this.herramientasGestiónToolStripMenuItem.Name = "herramientasGestiónToolStripMenuItem";
            this.herramientasGestiónToolStripMenuItem.Size = new System.Drawing.Size(145, 20);
            this.herramientasGestiónToolStripMenuItem.Text = "&Herramientas Movimientos";
            // 
            // comprasToolStripMenuItem
            // 
            this.comprasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroDeComprasToolStripMenuItem,
            this.toolStripMenuItem17,
            this.administradorDeComprasToolStripMenuItem,
            this.toolStripMenuItem5,
            this.cuentasPorPagarPorComprasToolStripMenuItem,
            this.toolStripMenuItem16,
            this.devoluciónDeComprasToolStripMenuItem,
            this.administradorDeDevolucionToolStripMenuItem});
            this.comprasToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.shoppingcart_full;
            this.comprasToolStripMenuItem.Name = "comprasToolStripMenuItem";
            this.comprasToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.comprasToolStripMenuItem.Text = "&Compras";
            // 
            // registroDeComprasToolStripMenuItem
            // 
            this.registroDeComprasToolStripMenuItem.Name = "registroDeComprasToolStripMenuItem";
            this.registroDeComprasToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.registroDeComprasToolStripMenuItem.Text = "&Registro de Compras";
            this.registroDeComprasToolStripMenuItem.Click += new System.EventHandler(this.registroDeComprasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(236, 6);
            // 
            // administradorDeComprasToolStripMenuItem
            // 
            this.administradorDeComprasToolStripMenuItem.Name = "administradorDeComprasToolStripMenuItem";
            this.administradorDeComprasToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.administradorDeComprasToolStripMenuItem.Text = "&Administrador de Compras";
            this.administradorDeComprasToolStripMenuItem.Click += new System.EventHandler(this.administradorDeComprasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(236, 6);
            // 
            // cuentasPorPagarPorComprasToolStripMenuItem
            // 
            this.cuentasPorPagarPorComprasToolStripMenuItem.Name = "cuentasPorPagarPorComprasToolStripMenuItem";
            this.cuentasPorPagarPorComprasToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.cuentasPorPagarPorComprasToolStripMenuItem.Text = "Cuentas por &Pagar por Compras";
            this.cuentasPorPagarPorComprasToolStripMenuItem.Click += new System.EventHandler(this.cuentasPorPagarPorComprasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(236, 6);
            // 
            // devoluciónDeComprasToolStripMenuItem
            // 
            this.devoluciónDeComprasToolStripMenuItem.Name = "devoluciónDeComprasToolStripMenuItem";
            this.devoluciónDeComprasToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.devoluciónDeComprasToolStripMenuItem.Text = "Devoluciones";
            this.devoluciónDeComprasToolStripMenuItem.Click += new System.EventHandler(this.devoluciónDeComprasToolStripMenuItem_Click);
            // 
            // administradorDeDevolucionToolStripMenuItem
            // 
            this.administradorDeDevolucionToolStripMenuItem.Name = "administradorDeDevolucionToolStripMenuItem";
            this.administradorDeDevolucionToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.administradorDeDevolucionToolStripMenuItem.Text = "Administrador de Devoluciones";
            this.administradorDeDevolucionToolStripMenuItem.Click += new System.EventHandler(this.administradorDeDevolucionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(246, 6);
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroDeVentasToolStripMenuItem,
            this.toolStripMenuItem7,
            this.administradorVentasToolStripMenuItem,
            this.toolStripMenuItem19,
            this.cuentasPorCobrarToolStripMenuItem,
            this.toolStripMenuItem18,
            this.devolucionesToolStripMenuItem,
            this.administradorDeDevolucionesToolStripMenuItem});
            this.ventasToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.shoppingcart;
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.ventasToolStripMenuItem.Text = "&Ventas";
            // 
            // registroDeVentasToolStripMenuItem
            // 
            this.registroDeVentasToolStripMenuItem.Name = "registroDeVentasToolStripMenuItem";
            this.registroDeVentasToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.registroDeVentasToolStripMenuItem.Text = "&Registro de Ventas";
            this.registroDeVentasToolStripMenuItem.Click += new System.EventHandler(this.registroDeVentasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(232, 6);
            // 
            // administradorVentasToolStripMenuItem
            // 
            this.administradorVentasToolStripMenuItem.Name = "administradorVentasToolStripMenuItem";
            this.administradorVentasToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.administradorVentasToolStripMenuItem.Text = "&Administrador Ventas";
            this.administradorVentasToolStripMenuItem.Click += new System.EventHandler(this.administradorVentasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(232, 6);
            // 
            // cuentasPorCobrarToolStripMenuItem
            // 
            this.cuentasPorCobrarToolStripMenuItem.Name = "cuentasPorCobrarToolStripMenuItem";
            this.cuentasPorCobrarToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.cuentasPorCobrarToolStripMenuItem.Text = "Cuentas Por &Cobrar por Ventas";
            this.cuentasPorCobrarToolStripMenuItem.Click += new System.EventHandler(this.cuentasPorCobrarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(232, 6);
            // 
            // devolucionesToolStripMenuItem
            // 
            this.devolucionesToolStripMenuItem.Name = "devolucionesToolStripMenuItem";
            this.devolucionesToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.devolucionesToolStripMenuItem.Text = "Devoluciones";
            this.devolucionesToolStripMenuItem.Click += new System.EventHandler(this.devolucionesToolStripMenuItem_Click);
            // 
            // administradorDeDevolucionesToolStripMenuItem
            // 
            this.administradorDeDevolucionesToolStripMenuItem.Name = "administradorDeDevolucionesToolStripMenuItem";
            this.administradorDeDevolucionesToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.administradorDeDevolucionesToolStripMenuItem.Text = "Administrador de Devoluciones";
            this.administradorDeDevolucionesToolStripMenuItem.Click += new System.EventHandler(this.administradorDeDevolucionesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(246, 6);
            // 
            // administradorCuentasPorPagarToolStripMenuItem
            // 
            this.administradorCuentasPorPagarToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.PAY00A;
            this.administradorCuentasPorPagarToolStripMenuItem.Name = "administradorCuentasPorPagarToolStripMenuItem";
            this.administradorCuentasPorPagarToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.administradorCuentasPorPagarToolStripMenuItem.Text = "Administrador Cuentas Por &Pagar";
            this.administradorCuentasPorPagarToolStripMenuItem.Click += new System.EventHandler(this.administradorCuentasPorPagarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(246, 6);
            // 
            // administradorCuentasPorCobrarToolStripMenuItem
            // 
            this.administradorCuentasPorCobrarToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.PAY00B;
            this.administradorCuentasPorCobrarToolStripMenuItem.Name = "administradorCuentasPorCobrarToolStripMenuItem";
            this.administradorCuentasPorCobrarToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.administradorCuentasPorCobrarToolStripMenuItem.Text = "Administrador Cuentas Por Co&brar";
            this.administradorCuentasPorCobrarToolStripMenuItem.Click += new System.EventHandler(this.administradorCuentasPorCobrarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(246, 6);
            // 
            // transferenciasToolStripMenuItem
            // 
            this.transferenciasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroDeTransferenciaToolStripMenuItem,
            this.administradorToolStripMenuItem});
            this.transferenciasToolStripMenuItem.Name = "transferenciasToolStripMenuItem";
            this.transferenciasToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.transferenciasToolStripMenuItem.Text = "Transferencias";
            // 
            // registroDeTransferenciaToolStripMenuItem
            // 
            this.registroDeTransferenciaToolStripMenuItem.Name = "registroDeTransferenciaToolStripMenuItem";
            this.registroDeTransferenciaToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.registroDeTransferenciaToolStripMenuItem.Text = "Registro de Transferencia";
            this.registroDeTransferenciaToolStripMenuItem.Click += new System.EventHandler(this.registroDeTransferenciaToolStripMenuItem_Click);
            // 
            // administradorToolStripMenuItem
            // 
            this.administradorToolStripMenuItem.Name = "administradorToolStripMenuItem";
            this.administradorToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.administradorToolStripMenuItem.Text = "Administrador de Transferencia";
            this.administradorToolStripMenuItem.Click += new System.EventHandler(this.administradorToolStripMenuItem_Click);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(158, 20);
            this.toolStripMenuItem37.Text = "&Administrador de Inventarios";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // configuraciónToolStripMenuItem
            // 
            this.configuraciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosToolStripMenuItem1,
            this.toolStripMenuItem10,
            this.procedenciaToolStripMenuItem,
            this.toolStripMenuItem14,
            this.conceptosToolStripMenuItem,
            this.toolStripMenuItem34,
            this.movilidadesToolStripMenuItem});
            this.configuraciónToolStripMenuItem.Name = "configuraciónToolStripMenuItem";
            this.configuraciónToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.configuraciónToolStripMenuItem.Text = "&Mantenimiento";
            // 
            // productosToolStripMenuItem1
            // 
            this.productosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unidadesToolStripMenuItem,
            this.tiposToolStripMenuItem,
            this.marcasToolStripMenuItem});
            this.productosToolStripMenuItem1.Name = "productosToolStripMenuItem1";
            this.productosToolStripMenuItem1.Size = new System.Drawing.Size(147, 22);
            this.productosToolStripMenuItem1.Text = "&Productos";
            // 
            // unidadesToolStripMenuItem
            // 
            this.unidadesToolStripMenuItem.Name = "unidadesToolStripMenuItem";
            this.unidadesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.unidadesToolStripMenuItem.Text = "&Unidades";
            this.unidadesToolStripMenuItem.Click += new System.EventHandler(this.unidadesToolStripMenuItem_Click);
            // 
            // tiposToolStripMenuItem
            // 
            this.tiposToolStripMenuItem.Name = "tiposToolStripMenuItem";
            this.tiposToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.tiposToolStripMenuItem.Text = "&Tipos";
            this.tiposToolStripMenuItem.Click += new System.EventHandler(this.tiposToolStripMenuItem_Click);
            // 
            // marcasToolStripMenuItem
            // 
            this.marcasToolStripMenuItem.Name = "marcasToolStripMenuItem";
            this.marcasToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.marcasToolStripMenuItem.Text = "&Marcas";
            this.marcasToolStripMenuItem.Click += new System.EventHandler(this.marcasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(144, 6);
            // 
            // procedenciaToolStripMenuItem
            // 
            this.procedenciaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aToolStripMenuItem,
            this.departamentosToolStripMenuItem,
            this.provinciasToolStripMenuItem,
            this.lugaresToolStripMenuItem,
            this.toolStripMenuItem15,
            this.administracionToolStripMenuItem});
            this.procedenciaToolStripMenuItem.Name = "procedenciaToolStripMenuItem";
            this.procedenciaToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.procedenciaToolStripMenuItem.Text = "Procedencia";
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.aToolStripMenuItem.Text = "&Naciones";
            this.aToolStripMenuItem.Click += new System.EventHandler(this.aToolStripMenuItem_Click);
            // 
            // departamentosToolStripMenuItem
            // 
            this.departamentosToolStripMenuItem.Name = "departamentosToolStripMenuItem";
            this.departamentosToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.departamentosToolStripMenuItem.Text = "&Departamentos";
            this.departamentosToolStripMenuItem.Click += new System.EventHandler(this.departamentosToolStripMenuItem_Click);
            // 
            // provinciasToolStripMenuItem
            // 
            this.provinciasToolStripMenuItem.Name = "provinciasToolStripMenuItem";
            this.provinciasToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.provinciasToolStripMenuItem.Text = "&Provincias";
            this.provinciasToolStripMenuItem.Click += new System.EventHandler(this.provinciasToolStripMenuItem_Click);
            // 
            // lugaresToolStripMenuItem
            // 
            this.lugaresToolStripMenuItem.Name = "lugaresToolStripMenuItem";
            this.lugaresToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.lugaresToolStripMenuItem.Text = "&Lugares ";
            this.lugaresToolStripMenuItem.Click += new System.EventHandler(this.lugaresToolStripMenuItem_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(156, 6);
            // 
            // administracionToolStripMenuItem
            // 
            this.administracionToolStripMenuItem.Name = "administracionToolStripMenuItem";
            this.administracionToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.administracionToolStripMenuItem.Text = "Administracion";
            this.administracionToolStripMenuItem.Click += new System.EventHandler(this.administracionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(144, 6);
            // 
            // conceptosToolStripMenuItem
            // 
            this.conceptosToolStripMenuItem.Name = "conceptosToolStripMenuItem";
            this.conceptosToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.conceptosToolStripMenuItem.Text = "&Conceptos";
            this.conceptosToolStripMenuItem.Click += new System.EventHandler(this.conceptosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(144, 6);
            // 
            // movilidadesToolStripMenuItem
            // 
            this.movilidadesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.movilidadesToolStripMenuItem1,
            this.tiposMovilidadesToolStripMenuItem});
            this.movilidadesToolStripMenuItem.Name = "movilidadesToolStripMenuItem";
            this.movilidadesToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.movilidadesToolStripMenuItem.Text = "Automotores";
            // 
            // movilidadesToolStripMenuItem1
            // 
            this.movilidadesToolStripMenuItem1.Name = "movilidadesToolStripMenuItem1";
            this.movilidadesToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.movilidadesToolStripMenuItem1.Text = "&Movilidades";
            this.movilidadesToolStripMenuItem1.Click += new System.EventHandler(this.movilidadesToolStripMenuItem1_Click);
            // 
            // tiposMovilidadesToolStripMenuItem
            // 
            this.tiposMovilidadesToolStripMenuItem.Name = "tiposMovilidadesToolStripMenuItem";
            this.tiposMovilidadesToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.tiposMovilidadesToolStripMenuItem.Text = "Modelos Movilidades";
            this.tiposMovilidadesToolStripMenuItem.Click += new System.EventHandler(this.tiposMovilidadesToolStripMenuItem_Click);
            // 
            // reportesToolStripMenuItem
            // 
            this.reportesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kardexDeProductoToolStripMenuItem,
            this.toolStripMenuItem11,
            this.movimientoDeAlmacenToolStripMenuItem,
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem,
            this.toolStripMenuItem12,
            this.otroToolStripMenuItem,
            this.toolStripMenuItem13,
            this.stockMinimoDeProductosToolStripMenuItem,
            this.toolStripMenuItem21,
            this.comprasToolStripMenuItem1,
            this.toolStripMenuItem22,
            this.ventasToolStripMenuItem1,
            this.toolStripMenuItem32,
            this.movimientoMonetarioToolStripMenuItem,
            this.toolStripMenuItem33,
            this.tiposDeProductoToolStripMenuItem,
            this.toolStripMenuItem35,
            this.devolucionesToolStripMenuItem1,
            this.toolStripMenuItem36,
            this.bitacoraToolStripMenuItem});
            this.reportesToolStripMenuItem.Image = global::SAlvecoComercial10.Properties.Resources.Document;
            this.reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            this.reportesToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.reportesToolStripMenuItem.Text = "&Reportes";
            // 
            // kardexDeProductoToolStripMenuItem
            // 
            this.kardexDeProductoToolStripMenuItem.Name = "kardexDeProductoToolStripMenuItem";
            this.kardexDeProductoToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.kardexDeProductoToolStripMenuItem.Text = "&Kardex de Producto";
            this.kardexDeProductoToolStripMenuItem.Click += new System.EventHandler(this.kardexDeProductoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(267, 6);
            // 
            // movimientoDeAlmacenToolStripMenuItem
            // 
            this.movimientoDeAlmacenToolStripMenuItem.Name = "movimientoDeAlmacenToolStripMenuItem";
            this.movimientoDeAlmacenToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.movimientoDeAlmacenToolStripMenuItem.Text = "&Movimiento de Almacen";
            this.movimientoDeAlmacenToolStripMenuItem.Click += new System.EventHandler(this.movimientoDeAlmacenToolStripMenuItem_Click);
            // 
            // movimientoAlmacenPorTipoProductoToolStripMenuItem
            // 
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem.Name = "movimientoAlmacenPorTipoProductoToolStripMenuItem";
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem.Text = "&Movimiento Almacen Por Tipo Producto";
            this.movimientoAlmacenPorTipoProductoToolStripMenuItem.Click += new System.EventHandler(this.movimientoAlmacenPorTipoProductoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(267, 6);
            // 
            // otroToolStripMenuItem
            // 
            this.otroToolStripMenuItem.Name = "otroToolStripMenuItem";
            this.otroToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.otroToolStripMenuItem.Text = "&Inventario de Almacenes";
            this.otroToolStripMenuItem.Click += new System.EventHandler(this.otroToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(267, 6);
            // 
            // stockMinimoDeProductosToolStripMenuItem
            // 
            this.stockMinimoDeProductosToolStripMenuItem.Name = "stockMinimoDeProductosToolStripMenuItem";
            this.stockMinimoDeProductosToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.stockMinimoDeProductosToolStripMenuItem.Text = "&Stock Minimo de Productos";
            this.stockMinimoDeProductosToolStripMenuItem.Click += new System.EventHandler(this.stockMinimoDeProductosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(267, 6);
            // 
            // comprasToolStripMenuItem1
            // 
            this.comprasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosEnEsperaToolStripMenuItem,
            this.toolStripMenuItem23,
            this.listaEnRangoDeFechasToolStripMenuItem,
            this.listadoPorTiposProductosToolStripMenuItem,
            this.toolStripMenuItem24,
            this.listadoPorProveedorToolStripMenuItem,
            this.listadoPorProveedorYTiposProductosToolStripMenuItem,
            this.toolStripMenuItem25,
            this.listadoPorUsuarioToolStripMenuItem,
            this.resumenMovimientoToolStripMenuItem,
            this.toolStripMenuItem29,
            this.cuentasPorPagarToolStripMenuItem});
            this.comprasToolStripMenuItem1.Name = "comprasToolStripMenuItem1";
            this.comprasToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.comprasToolStripMenuItem1.Text = "&Compras";
            // 
            // productosEnEsperaToolStripMenuItem
            // 
            this.productosEnEsperaToolStripMenuItem.Name = "productosEnEsperaToolStripMenuItem";
            this.productosEnEsperaToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.productosEnEsperaToolStripMenuItem.Text = "&Productos en Espera";
            this.productosEnEsperaToolStripMenuItem.Click += new System.EventHandler(this.productosEnEsperaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(276, 6);
            // 
            // listaEnRangoDeFechasToolStripMenuItem
            // 
            this.listaEnRangoDeFechasToolStripMenuItem.Name = "listaEnRangoDeFechasToolStripMenuItem";
            this.listaEnRangoDeFechasToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.listaEnRangoDeFechasToolStripMenuItem.Text = "Listado en Rango de Fechas";
            this.listaEnRangoDeFechasToolStripMenuItem.Click += new System.EventHandler(this.listaEnRangoDeFechasToolStripMenuItem_Click);
            // 
            // listadoPorTiposProductosToolStripMenuItem
            // 
            this.listadoPorTiposProductosToolStripMenuItem.Name = "listadoPorTiposProductosToolStripMenuItem";
            this.listadoPorTiposProductosToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.listadoPorTiposProductosToolStripMenuItem.Text = "Listado Por Tipos Productos";
            this.listadoPorTiposProductosToolStripMenuItem.Click += new System.EventHandler(this.listadoPorTiposProductosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(276, 6);
            // 
            // listadoPorProveedorToolStripMenuItem
            // 
            this.listadoPorProveedorToolStripMenuItem.Name = "listadoPorProveedorToolStripMenuItem";
            this.listadoPorProveedorToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.listadoPorProveedorToolStripMenuItem.Text = "Listado Por Proveedor";
            this.listadoPorProveedorToolStripMenuItem.Click += new System.EventHandler(this.listadoPorProveedorToolStripMenuItem_Click);
            // 
            // listadoPorProveedorYTiposProductosToolStripMenuItem
            // 
            this.listadoPorProveedorYTiposProductosToolStripMenuItem.Name = "listadoPorProveedorYTiposProductosToolStripMenuItem";
            this.listadoPorProveedorYTiposProductosToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.listadoPorProveedorYTiposProductosToolStripMenuItem.Text = "Listado Por Proveedor y Tipos Productos";
            this.listadoPorProveedorYTiposProductosToolStripMenuItem.Click += new System.EventHandler(this.listadoPorProveedorYTiposProductosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(276, 6);
            // 
            // listadoPorUsuarioToolStripMenuItem
            // 
            this.listadoPorUsuarioToolStripMenuItem.Name = "listadoPorUsuarioToolStripMenuItem";
            this.listadoPorUsuarioToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.listadoPorUsuarioToolStripMenuItem.Text = "Listado por Usuario";
            this.listadoPorUsuarioToolStripMenuItem.Click += new System.EventHandler(this.listadoPorUsuarioToolStripMenuItem_Click);
            // 
            // resumenMovimientoToolStripMenuItem
            // 
            this.resumenMovimientoToolStripMenuItem.Name = "resumenMovimientoToolStripMenuItem";
            this.resumenMovimientoToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.resumenMovimientoToolStripMenuItem.Text = "Resumen Movimiento";
            this.resumenMovimientoToolStripMenuItem.Click += new System.EventHandler(this.resumenMovimientoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(276, 6);
            // 
            // cuentasPorPagarToolStripMenuItem
            // 
            this.cuentasPorPagarToolStripMenuItem.Name = "cuentasPorPagarToolStripMenuItem";
            this.cuentasPorPagarToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.cuentasPorPagarToolStripMenuItem.Text = "Cuentas por Pagar";
            this.cuentasPorPagarToolStripMenuItem.Click += new System.EventHandler(this.cuentasPorPagarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(267, 6);
            // 
            // ventasToolStripMenuItem1
            // 
            this.ventasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listadoEnRangoDeFechasToolStripMenuItem,
            this.listadoPorTiposProductosToolStripMenuItem1,
            this.toolStripMenuItem26,
            this.listadoPorClientesToolStripMenuItem,
            this.listadoPorClientesYTiposProductosToolStripMenuItem,
            this.toolStripMenuItem27,
            this.distribucionDeProductosToolStripMenuItem,
            this.distribucionDeProductosPorClienteToolStripMenuItem,
            this.toolStripMenuItem31,
            this.listadoPorUsuariosToolStripMenuItem,
            this.resumenMovimientoToolStripMenuItem1,
            this.toolStripMenuItem30,
            this.cuentasPorCobrarToolStripMenuItem1});
            this.ventasToolStripMenuItem1.Name = "ventasToolStripMenuItem1";
            this.ventasToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.ventasToolStripMenuItem1.Text = "&Ventas";
            // 
            // listadoEnRangoDeFechasToolStripMenuItem
            // 
            this.listadoEnRangoDeFechasToolStripMenuItem.Name = "listadoEnRangoDeFechasToolStripMenuItem";
            this.listadoEnRangoDeFechasToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.listadoEnRangoDeFechasToolStripMenuItem.Text = "Listado en Rango de Fechas";
            this.listadoEnRangoDeFechasToolStripMenuItem.Click += new System.EventHandler(this.listadoEnRangoDeFechasToolStripMenuItem_Click);
            // 
            // listadoPorTiposProductosToolStripMenuItem1
            // 
            this.listadoPorTiposProductosToolStripMenuItem1.Name = "listadoPorTiposProductosToolStripMenuItem1";
            this.listadoPorTiposProductosToolStripMenuItem1.Size = new System.Drawing.Size(267, 22);
            this.listadoPorTiposProductosToolStripMenuItem1.Text = "Listado por Tipos Productos";
            this.listadoPorTiposProductosToolStripMenuItem1.Click += new System.EventHandler(this.listadoPorTiposProductosToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(264, 6);
            // 
            // listadoPorClientesToolStripMenuItem
            // 
            this.listadoPorClientesToolStripMenuItem.Name = "listadoPorClientesToolStripMenuItem";
            this.listadoPorClientesToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.listadoPorClientesToolStripMenuItem.Text = "Listado Por Clientes";
            this.listadoPorClientesToolStripMenuItem.Click += new System.EventHandler(this.listadoPorClientesToolStripMenuItem_Click);
            // 
            // listadoPorClientesYTiposProductosToolStripMenuItem
            // 
            this.listadoPorClientesYTiposProductosToolStripMenuItem.Name = "listadoPorClientesYTiposProductosToolStripMenuItem";
            this.listadoPorClientesYTiposProductosToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.listadoPorClientesYTiposProductosToolStripMenuItem.Text = "Listado Por Clientes y Tipos Productos";
            this.listadoPorClientesYTiposProductosToolStripMenuItem.Click += new System.EventHandler(this.listadoPorClientesYTiposProductosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(264, 6);
            // 
            // distribucionDeProductosToolStripMenuItem
            // 
            this.distribucionDeProductosToolStripMenuItem.Name = "distribucionDeProductosToolStripMenuItem";
            this.distribucionDeProductosToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.distribucionDeProductosToolStripMenuItem.Text = "Distribucion de Productos";
            this.distribucionDeProductosToolStripMenuItem.Click += new System.EventHandler(this.distribucionDeProductosToolStripMenuItem_Click);
            // 
            // distribucionDeProductosPorClienteToolStripMenuItem
            // 
            this.distribucionDeProductosPorClienteToolStripMenuItem.Name = "distribucionDeProductosPorClienteToolStripMenuItem";
            this.distribucionDeProductosPorClienteToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.distribucionDeProductosPorClienteToolStripMenuItem.Text = "Distribucion de Productos Por Cliente";
            this.distribucionDeProductosPorClienteToolStripMenuItem.Click += new System.EventHandler(this.distribucionDeProductosPorClienteToolStripMenuItem_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(264, 6);
            // 
            // listadoPorUsuariosToolStripMenuItem
            // 
            this.listadoPorUsuariosToolStripMenuItem.Name = "listadoPorUsuariosToolStripMenuItem";
            this.listadoPorUsuariosToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.listadoPorUsuariosToolStripMenuItem.Text = "Listado Por Usuarios";
            this.listadoPorUsuariosToolStripMenuItem.Click += new System.EventHandler(this.listadoPorUsuariosToolStripMenuItem_Click);
            // 
            // resumenMovimientoToolStripMenuItem1
            // 
            this.resumenMovimientoToolStripMenuItem1.Name = "resumenMovimientoToolStripMenuItem1";
            this.resumenMovimientoToolStripMenuItem1.Size = new System.Drawing.Size(267, 22);
            this.resumenMovimientoToolStripMenuItem1.Text = "Resumen Movimiento";
            this.resumenMovimientoToolStripMenuItem1.Click += new System.EventHandler(this.resumenMovimientoToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(264, 6);
            // 
            // cuentasPorCobrarToolStripMenuItem1
            // 
            this.cuentasPorCobrarToolStripMenuItem1.Name = "cuentasPorCobrarToolStripMenuItem1";
            this.cuentasPorCobrarToolStripMenuItem1.Size = new System.Drawing.Size(267, 22);
            this.cuentasPorCobrarToolStripMenuItem1.Text = "Cuentas por Cobrar";
            this.cuentasPorCobrarToolStripMenuItem1.Click += new System.EventHandler(this.cuentasPorCobrarToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(267, 6);
            // 
            // movimientoMonetarioToolStripMenuItem
            // 
            this.movimientoMonetarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.porUsuarioToolStripMenuItem,
            this.generalToolStripMenuItem,
            this.porDistribuidorToolStripMenuItem});
            this.movimientoMonetarioToolStripMenuItem.Name = "movimientoMonetarioToolStripMenuItem";
            this.movimientoMonetarioToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.movimientoMonetarioToolStripMenuItem.Text = "Movimiento Economico";
            // 
            // porUsuarioToolStripMenuItem
            // 
            this.porUsuarioToolStripMenuItem.Name = "porUsuarioToolStripMenuItem";
            this.porUsuarioToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.porUsuarioToolStripMenuItem.Text = "Por Usuario";
            this.porUsuarioToolStripMenuItem.Click += new System.EventHandler(this.porUsuarioToolStripMenuItem_Click);
            // 
            // generalToolStripMenuItem
            // 
            this.generalToolStripMenuItem.Name = "generalToolStripMenuItem";
            this.generalToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.generalToolStripMenuItem.Text = "General";
            this.generalToolStripMenuItem.Click += new System.EventHandler(this.generalToolStripMenuItem_Click);
            // 
            // porDistribuidorToolStripMenuItem
            // 
            this.porDistribuidorToolStripMenuItem.Name = "porDistribuidorToolStripMenuItem";
            this.porDistribuidorToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.porDistribuidorToolStripMenuItem.Text = "Por Distribuidor";
            this.porDistribuidorToolStripMenuItem.Click += new System.EventHandler(this.porDistribuidorToolStripMenuItem_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(267, 6);
            // 
            // tiposDeProductoToolStripMenuItem
            // 
            this.tiposDeProductoToolStripMenuItem.Name = "tiposDeProductoToolStripMenuItem";
            this.tiposDeProductoToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.tiposDeProductoToolStripMenuItem.Text = "Tipos de Producto";
            this.tiposDeProductoToolStripMenuItem.Click += new System.EventHandler(this.tiposDeProductoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(267, 6);
            // 
            // devolucionesToolStripMenuItem1
            // 
            this.devolucionesToolStripMenuItem1.Name = "devolucionesToolStripMenuItem1";
            this.devolucionesToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.devolucionesToolStripMenuItem1.Text = "&Devoluciones";
            this.devolucionesToolStripMenuItem1.Click += new System.EventHandler(this.devolucionesToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(267, 6);
            // 
            // bitacoraToolStripMenuItem
            // 
            this.bitacoraToolStripMenuItem.Name = "bitacoraToolStripMenuItem";
            this.bitacoraToolStripMenuItem.Size = new System.Drawing.Size(270, 22);
            this.bitacoraToolStripMenuItem.Text = "&Bitacora";
            this.bitacoraToolStripMenuItem.Click += new System.EventHandler(this.bitacoraToolStripMenuItem_Click);
            // 
            // FPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SAlvecoComercial10.Properties.Resources.Fondo;
            this.ClientSize = new System.Drawing.Size(771, 562);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.sSPrincipal);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Gestión de Compras y Ventas - Seguimiento de Almacen";
            this.Load += new System.EventHandler(this.FPrincipal_Load);
            this.sSPrincipal.ResumeLayout(false);
            this.sSPrincipal.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip sSPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tsLblNombreServidor;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionBDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiaDeSeguridadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaurarCopiaDeSeguridadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administraciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem almacenesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cambiarContraseñaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem salirDelSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestiónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem proveedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem herramientasGestiónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administradorDeComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroDeComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem cuentasPorPagarPorComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administradorVentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroDeVentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem cuentasPorCobrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem administradorCuentasPorPagarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem administradorCuentasPorCobrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem unidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marcasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem procedenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem departamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem provinciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lugaresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kardexDeProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem movimientoDeAlmacenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimientoAlmacenPorTipoProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem otroToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem stockMinimoDeProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem14;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem administracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem devoluciónDeComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administradorDeDevolucionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem administradorDeDevolucionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem19;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem devolucionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem productosEnEsperaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem listaEnRangoDeFechasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoPorTiposProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem listadoPorProveedorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoPorProveedorYTiposProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem cuentasPorPagarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listadoEnRangoDeFechasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoPorTiposProductosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem listadoPorClientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoPorClientesYTiposProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem cuentasPorCobrarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem personasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoPorUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumenMovimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem listadoPorUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem distribucionDeProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumenMovimientoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem distribucionDeProductosPorClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem31;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem movimientoMonetarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generalToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem tiposDeProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceptosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem porDistribuidorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem devolucionesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem bitacoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem movilidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movilidadesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tiposMovilidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel tslblNumeroAlmacen;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem transferenciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroDeTransferenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administradorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiarDeAlmacenToolStripMenuItem;
    }
}