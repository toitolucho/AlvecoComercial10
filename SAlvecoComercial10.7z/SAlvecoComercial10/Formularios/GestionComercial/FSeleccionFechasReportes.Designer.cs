﻿namespace SAlvecoComercial10.Formularios.GestionComercial
{
    partial class FSeleccionFechasReportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gBoxRangoFechas = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gBoxFiltro = new System.Windows.Forms.GroupBox();
            this.cBoxFiltro = new System.Windows.Forms.ComboBox();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gBoxRangoFechas.SuspendLayout();
            this.gBoxFiltro.SuspendLayout();
            this.SuspendLayout();
            // 
            // gBoxRangoFechas
            // 
            this.gBoxRangoFechas.Controls.Add(this.dateTimePicker2);
            this.gBoxRangoFechas.Controls.Add(this.dateTimePicker1);
            this.gBoxRangoFechas.Controls.Add(this.label2);
            this.gBoxRangoFechas.Controls.Add(this.label1);
            this.gBoxRangoFechas.Location = new System.Drawing.Point(16, 15);
            this.gBoxRangoFechas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxRangoFechas.Name = "gBoxRangoFechas";
            this.gBoxRangoFechas.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxRangoFechas.Size = new System.Drawing.Size(268, 94);
            this.gBoxRangoFechas.TabIndex = 0;
            this.gBoxRangoFechas.TabStop = false;
            this.gBoxRangoFechas.Text = "Rango de Fechas";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(49, 57);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(205, 22);
            this.dateTimePicker2.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(49, 25);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(205, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Al";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Del";
            // 
            // gBoxFiltro
            // 
            this.gBoxFiltro.Controls.Add(this.cBoxFiltro);
            this.gBoxFiltro.Controls.Add(this.lblFiltro);
            this.gBoxFiltro.Location = new System.Drawing.Point(17, 117);
            this.gBoxFiltro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxFiltro.Name = "gBoxFiltro";
            this.gBoxFiltro.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxFiltro.Size = new System.Drawing.Size(267, 82);
            this.gBoxFiltro.TabIndex = 1;
            this.gBoxFiltro.TabStop = false;
            this.gBoxFiltro.Text = "Filtro";
            // 
            // cBoxFiltro
            // 
            this.cBoxFiltro.FormattingEnabled = true;
            this.cBoxFiltro.Location = new System.Drawing.Point(17, 39);
            this.cBoxFiltro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cBoxFiltro.Name = "cBoxFiltro";
            this.cBoxFiltro.Size = new System.Drawing.Size(236, 24);
            this.cBoxFiltro.TabIndex = 5;
            // 
            // lblFiltro
            // 
            this.lblFiltro.AutoSize = true;
            this.lblFiltro.Location = new System.Drawing.Point(17, 20);
            this.lblFiltro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(52, 17);
            this.lblFiltro.TabIndex = 4;
            this.lblFiltro.Text = "Oficina";
            // 
            // btnAceptar
            // 
            this.btnAceptar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceptar.Image = global::SAlvecoComercial10.Properties.Resources.accept;
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptar.Location = new System.Drawing.Point(85, 210);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(92, 28);
            this.btnAceptar.TabIndex = 2;
            this.btnAceptar.Text = "&Aceptar";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Image = global::SAlvecoComercial10.Properties.Resources.arrow_rotate_clockwise;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(185, 210);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(99, 28);
            this.btnCancelar.TabIndex = 3;
            this.btnCancelar.Text = "&Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // FSeleccionFechasReportes
            // 
            this.AcceptButton = this.btnAceptar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.CancelButton = this.btnCancelar;
            this.ClientSize = new System.Drawing.Size(296, 247);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.gBoxFiltro);
            this.Controls.Add(this.gBoxRangoFechas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FSeleccionFechasReportes";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seleccione el Rango de Fechas";
            this.gBoxRangoFechas.ResumeLayout(false);
            this.gBoxRangoFechas.PerformLayout();
            this.gBoxFiltro.ResumeLayout(false);
            this.gBoxFiltro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gBoxRangoFechas;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gBoxFiltro;
        private System.Windows.Forms.ComboBox cBoxFiltro;
        private System.Windows.Forms.Label lblFiltro;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
    }
}