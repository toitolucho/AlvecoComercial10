﻿namespace SAlvecoComercial10.Formularios.GestionComercial
{
    partial class FTransaccionesCuentasPorPagarCobrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dtGVCuentasPorPagar = new System.Windows.Forms.DataGridView();
            this.pnlResumenteCuentasPorPagar = new System.Windows.Forms.Panel();
            this.txtBoxTCompraCP = new System.Windows.Forms.TextBox();
            this.txtBoxTCuentaCP = new System.Windows.Forms.TextBox();
            this.txtBoxTPagadoCP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxTDiferenciaCP = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dtGVCuentasPorCobrar = new System.Windows.Forms.DataGridView();
            this.DGCNombreRazonSocial2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.pnlResumenCuentasPorCobrar = new System.Windows.Forms.Panel();
            this.txtBoxTCompraCC = new System.Windows.Forms.TextBox();
            this.txtBoxTCuentaCC = new System.Windows.Forms.TextBox();
            this.txtBoxTCobradoCC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxTDiferenciaCC = new System.Windows.Forms.TextBox();
            this.pnlInferiorBotones = new System.Windows.Forms.Panel();
            this.gBoxFiltrado = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnFiltrar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.checkListartodos = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dPickeFechaHoraInicio = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dPickerFechaHoraFin = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDetalle = new System.Windows.Forms.Button();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.gBoxOpciones = new System.Windows.Forms.GroupBox();
            this.rBtnDetalleCuenta = new System.Windows.Forms.RadioButton();
            this.rBtnDetalleCompra = new System.Windows.Forms.RadioButton();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCDatosUsuario2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNumeroCompraProducto2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCFecha2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNumeroCuentaPorCobrar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoTotalCompra2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoCuentaPorCobrar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoPagado2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoDiferencia2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNombreMoneda2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCObservaciones2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCDatosUsuario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNumeroCompraProducto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNombreRazonSocial = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DGCFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNumeroCuentaPorPagar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCTipoCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNombreRepresentante = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoTotalCompra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMonto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoPagado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCMontoDiferencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCNombreMoneda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGCObservaciones = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGVCuentasPorPagar)).BeginInit();
            this.pnlResumenteCuentasPorPagar.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGVCuentasPorCobrar)).BeginInit();
            this.pnlResumenCuentasPorCobrar.SuspendLayout();
            this.pnlInferiorBotones.SuspendLayout();
            this.gBoxFiltrado.SuspendLayout();
            this.gBoxOpciones.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1028, 517);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dtGVCuentasPorPagar);
            this.tabPage1.Controls.Add(this.pnlResumenteCuentasPorPagar);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(9, 9, 9, 9);
            this.tabPage1.Size = new System.Drawing.Size(1020, 488);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cuentas Por Pagar";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dtGVCuentasPorPagar
            // 
            this.dtGVCuentasPorPagar.AllowUserToAddRows = false;
            this.dtGVCuentasPorPagar.AllowUserToDeleteRows = false;
            this.dtGVCuentasPorPagar.AllowUserToResizeRows = false;
            this.dtGVCuentasPorPagar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGVCuentasPorPagar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtGVCuentasPorPagar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGVCuentasPorPagar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DGCDatosUsuario,
            this.DGCNumeroCompraProducto,
            this.DGCNombreRazonSocial,
            this.DGCFecha,
            this.DGCNumeroCuentaPorPagar,
            this.DGCTipoCliente,
            this.DGCNombreRepresentante,
            this.DGCMontoTotalCompra,
            this.DGCMonto,
            this.DGCMontoPagado,
            this.DGCMontoDiferencia,
            this.DGCNombreMoneda,
            this.DGCObservaciones});
            this.dtGVCuentasPorPagar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtGVCuentasPorPagar.Location = new System.Drawing.Point(9, 9);
            this.dtGVCuentasPorPagar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtGVCuentasPorPagar.MultiSelect = false;
            this.dtGVCuentasPorPagar.Name = "dtGVCuentasPorPagar";
            this.dtGVCuentasPorPagar.RowTemplate.Height = 24;
            this.dtGVCuentasPorPagar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGVCuentasPorPagar.Size = new System.Drawing.Size(1002, 431);
            this.dtGVCuentasPorPagar.TabIndex = 0;
            this.dtGVCuentasPorPagar.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGVCuentasPorPagar_CellDoubleClick);
            this.dtGVCuentasPorPagar.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dtGVCuentasPorPagar_DataError);
            // 
            // pnlResumenteCuentasPorPagar
            // 
            this.pnlResumenteCuentasPorPagar.Controls.Add(this.txtBoxTCompraCP);
            this.pnlResumenteCuentasPorPagar.Controls.Add(this.txtBoxTCuentaCP);
            this.pnlResumenteCuentasPorPagar.Controls.Add(this.txtBoxTPagadoCP);
            this.pnlResumenteCuentasPorPagar.Controls.Add(this.label3);
            this.pnlResumenteCuentasPorPagar.Controls.Add(this.txtBoxTDiferenciaCP);
            this.pnlResumenteCuentasPorPagar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlResumenteCuentasPorPagar.Location = new System.Drawing.Point(9, 440);
            this.pnlResumenteCuentasPorPagar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlResumenteCuentasPorPagar.Name = "pnlResumenteCuentasPorPagar";
            this.pnlResumenteCuentasPorPagar.Size = new System.Drawing.Size(1002, 39);
            this.pnlResumenteCuentasPorPagar.TabIndex = 5;
            // 
            // txtBoxTCompraCP
            // 
            this.txtBoxTCompraCP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTCompraCP.BackColor = System.Drawing.Color.Black;
            this.txtBoxTCompraCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTCompraCP.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTCompraCP.Location = new System.Drawing.Point(275, 7);
            this.txtBoxTCompraCP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTCompraCP.Name = "txtBoxTCompraCP";
            this.txtBoxTCompraCP.Size = new System.Drawing.Size(129, 23);
            this.txtBoxTCompraCP.TabIndex = 6;
            this.txtBoxTCompraCP.Text = "0.00";
            this.txtBoxTCompraCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxTCuentaCP
            // 
            this.txtBoxTCuentaCP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTCuentaCP.BackColor = System.Drawing.Color.Black;
            this.txtBoxTCuentaCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTCuentaCP.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTCuentaCP.Location = new System.Drawing.Point(406, 7);
            this.txtBoxTCuentaCP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTCuentaCP.Name = "txtBoxTCuentaCP";
            this.txtBoxTCuentaCP.Size = new System.Drawing.Size(129, 23);
            this.txtBoxTCuentaCP.TabIndex = 5;
            this.txtBoxTCuentaCP.Text = "0.00";
            this.txtBoxTCuentaCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxTPagadoCP
            // 
            this.txtBoxTPagadoCP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTPagadoCP.BackColor = System.Drawing.Color.Black;
            this.txtBoxTPagadoCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTPagadoCP.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTPagadoCP.Location = new System.Drawing.Point(538, 7);
            this.txtBoxTPagadoCP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTPagadoCP.Name = "txtBoxTPagadoCP";
            this.txtBoxTPagadoCP.Size = new System.Drawing.Size(129, 23);
            this.txtBoxTPagadoCP.TabIndex = 4;
            this.txtBoxTPagadoCP.Text = "0.00";
            this.txtBoxTPagadoCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(448, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Totales";
            // 
            // txtBoxTDiferenciaCP
            // 
            this.txtBoxTDiferenciaCP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTDiferenciaCP.BackColor = System.Drawing.Color.Black;
            this.txtBoxTDiferenciaCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTDiferenciaCP.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTDiferenciaCP.Location = new System.Drawing.Point(667, 7);
            this.txtBoxTDiferenciaCP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTDiferenciaCP.Name = "txtBoxTDiferenciaCP";
            this.txtBoxTDiferenciaCP.Size = new System.Drawing.Size(129, 23);
            this.txtBoxTDiferenciaCP.TabIndex = 3;
            this.txtBoxTDiferenciaCP.Text = "0.00";
            this.txtBoxTDiferenciaCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dtGVCuentasPorCobrar);
            this.tabPage2.Controls.Add(this.pnlResumenCuentasPorCobrar);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(9, 9, 9, 9);
            this.tabPage2.Size = new System.Drawing.Size(1020, 488);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cuentas Por Cobrar";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dtGVCuentasPorCobrar
            // 
            this.dtGVCuentasPorCobrar.AllowUserToAddRows = false;
            this.dtGVCuentasPorCobrar.AllowUserToDeleteRows = false;
            this.dtGVCuentasPorCobrar.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGVCuentasPorCobrar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtGVCuentasPorCobrar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGVCuentasPorCobrar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DGCDatosUsuario2,
            this.DGCNumeroCompraProducto2,
            this.DGCNombreRazonSocial2,
            this.DGCFecha2,
            this.DGCNumeroCuentaPorCobrar,
            this.DGCMontoTotalCompra2,
            this.DGCMontoCuentaPorCobrar,
            this.DGCMontoPagado2,
            this.DGCMontoDiferencia2,
            this.DGCNombreMoneda2,
            this.DGCObservaciones2});
            this.dtGVCuentasPorCobrar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtGVCuentasPorCobrar.Location = new System.Drawing.Point(9, 9);
            this.dtGVCuentasPorCobrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtGVCuentasPorCobrar.MultiSelect = false;
            this.dtGVCuentasPorCobrar.Name = "dtGVCuentasPorCobrar";
            this.dtGVCuentasPorCobrar.RowHeadersVisible = false;
            this.dtGVCuentasPorCobrar.RowTemplate.Height = 24;
            this.dtGVCuentasPorCobrar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGVCuentasPorCobrar.Size = new System.Drawing.Size(1002, 432);
            this.dtGVCuentasPorCobrar.TabIndex = 1;
            this.dtGVCuentasPorCobrar.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtGVCuentasPorPagar_CellDoubleClick);
            // 
            // DGCNombreRazonSocial2
            // 
            this.DGCNombreRazonSocial2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.DGCNombreRazonSocial2.DataPropertyName = "NombreCliente";
            this.DGCNombreRazonSocial2.FillWeight = 200F;
            this.DGCNombreRazonSocial2.HeaderText = "Proveedor";
            this.DGCNombreRazonSocial2.Name = "DGCNombreRazonSocial2";
            this.DGCNombreRazonSocial2.ReadOnly = true;
            this.DGCNombreRazonSocial2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DGCNombreRazonSocial2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.DGCNombreRazonSocial2.Width = 97;
            // 
            // pnlResumenCuentasPorCobrar
            // 
            this.pnlResumenCuentasPorCobrar.Controls.Add(this.txtBoxTCompraCC);
            this.pnlResumenCuentasPorCobrar.Controls.Add(this.txtBoxTCuentaCC);
            this.pnlResumenCuentasPorCobrar.Controls.Add(this.txtBoxTCobradoCC);
            this.pnlResumenCuentasPorCobrar.Controls.Add(this.label2);
            this.pnlResumenCuentasPorCobrar.Controls.Add(this.txtBoxTDiferenciaCC);
            this.pnlResumenCuentasPorCobrar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlResumenCuentasPorCobrar.Location = new System.Drawing.Point(9, 441);
            this.pnlResumenCuentasPorCobrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlResumenCuentasPorCobrar.Name = "pnlResumenCuentasPorCobrar";
            this.pnlResumenCuentasPorCobrar.Size = new System.Drawing.Size(1002, 38);
            this.pnlResumenCuentasPorCobrar.TabIndex = 4;
            // 
            // txtBoxTCompraCC
            // 
            this.txtBoxTCompraCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTCompraCC.BackColor = System.Drawing.Color.Black;
            this.txtBoxTCompraCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTCompraCC.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTCompraCC.Location = new System.Drawing.Point(355, 6);
            this.txtBoxTCompraCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTCompraCC.Name = "txtBoxTCompraCC";
            this.txtBoxTCompraCC.Size = new System.Drawing.Size(113, 23);
            this.txtBoxTCompraCC.TabIndex = 6;
            this.txtBoxTCompraCC.Text = "0.00";
            this.txtBoxTCompraCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxTCuentaCC
            // 
            this.txtBoxTCuentaCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTCuentaCC.BackColor = System.Drawing.Color.Black;
            this.txtBoxTCuentaCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTCuentaCC.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTCuentaCC.Location = new System.Drawing.Point(470, 6);
            this.txtBoxTCuentaCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTCuentaCC.Name = "txtBoxTCuentaCC";
            this.txtBoxTCuentaCC.Size = new System.Drawing.Size(113, 23);
            this.txtBoxTCuentaCC.TabIndex = 5;
            this.txtBoxTCuentaCC.Text = "0.00";
            this.txtBoxTCuentaCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxTCobradoCC
            // 
            this.txtBoxTCobradoCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTCobradoCC.BackColor = System.Drawing.Color.Black;
            this.txtBoxTCobradoCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTCobradoCC.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTCobradoCC.Location = new System.Drawing.Point(584, 6);
            this.txtBoxTCobradoCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTCobradoCC.Name = "txtBoxTCobradoCC";
            this.txtBoxTCobradoCC.Size = new System.Drawing.Size(113, 23);
            this.txtBoxTCobradoCC.TabIndex = 4;
            this.txtBoxTCobradoCC.Text = "0.00";
            this.txtBoxTCobradoCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(536, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Totales";
            // 
            // txtBoxTDiferenciaCC
            // 
            this.txtBoxTDiferenciaCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTDiferenciaCC.BackColor = System.Drawing.Color.Black;
            this.txtBoxTDiferenciaCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTDiferenciaCC.ForeColor = System.Drawing.Color.GreenYellow;
            this.txtBoxTDiferenciaCC.Location = new System.Drawing.Point(699, 6);
            this.txtBoxTDiferenciaCC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBoxTDiferenciaCC.Name = "txtBoxTDiferenciaCC";
            this.txtBoxTDiferenciaCC.Size = new System.Drawing.Size(113, 23);
            this.txtBoxTDiferenciaCC.TabIndex = 3;
            this.txtBoxTDiferenciaCC.Text = "0.00";
            this.txtBoxTDiferenciaCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pnlInferiorBotones
            // 
            this.pnlInferiorBotones.Controls.Add(this.gBoxFiltrado);
            this.pnlInferiorBotones.Controls.Add(this.label1);
            this.pnlInferiorBotones.Controls.Add(this.btnDetalle);
            this.pnlInferiorBotones.Controls.Add(this.btnCerrar);
            this.pnlInferiorBotones.Controls.Add(this.gBoxOpciones);
            this.pnlInferiorBotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlInferiorBotones.Location = new System.Drawing.Point(0, 517);
            this.pnlInferiorBotones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlInferiorBotones.Name = "pnlInferiorBotones";
            this.pnlInferiorBotones.Size = new System.Drawing.Size(1028, 81);
            this.pnlInferiorBotones.TabIndex = 1;
            // 
            // gBoxFiltrado
            // 
            this.gBoxFiltrado.Controls.Add(this.label4);
            this.gBoxFiltrado.Controls.Add(this.btnFiltrar);
            this.gBoxFiltrado.Controls.Add(this.label6);
            this.gBoxFiltrado.Controls.Add(this.checkListartodos);
            this.gBoxFiltrado.Controls.Add(this.label5);
            this.gBoxFiltrado.Controls.Add(this.dPickeFechaHoraInicio);
            this.gBoxFiltrado.Controls.Add(this.textBox1);
            this.gBoxFiltrado.Controls.Add(this.dPickerFechaHoraFin);
            this.gBoxFiltrado.Location = new System.Drawing.Point(536, 4);
            this.gBoxFiltrado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxFiltrado.Name = "gBoxFiltrado";
            this.gBoxFiltrado.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxFiltrado.Size = new System.Drawing.Size(519, 74);
            this.gBoxFiltrado.TabIndex = 12;
            this.gBoxFiltrado.TabStop = false;
            this.gBoxFiltrado.Text = "Filtrar Por";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 21);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Del";
            // 
            // btnFiltrar
            // 
            this.btnFiltrar.Location = new System.Drawing.Point(411, 37);
            this.btnFiltrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFiltrar.Name = "btnFiltrar";
            this.btnFiltrar.Size = new System.Drawing.Size(100, 28);
            this.btnFiltrar.TabIndex = 4;
            this.btnFiltrar.Text = "&Actualizar";
            this.btnFiltrar.UseVisualStyleBackColor = true;
            this.btnFiltrar.Click += new System.EventHandler(this.btnFiltrar_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 48);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Nro Orden Compra";
            // 
            // checkListartodos
            // 
            this.checkListartodos.AutoSize = true;
            this.checkListartodos.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkListartodos.Location = new System.Drawing.Point(307, 46);
            this.checkListartodos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkListartodos.Name = "checkListartodos";
            this.checkListartodos.Size = new System.Drawing.Size(70, 21);
            this.checkListartodos.TabIndex = 11;
            this.checkListartodos.Text = "Todos";
            this.checkListartodos.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(211, 21);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Al";
            // 
            // dPickeFechaHoraInicio
            // 
            this.dPickeFechaHoraInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dPickeFechaHoraInicio.Location = new System.Drawing.Point(69, 16);
            this.dPickeFechaHoraInicio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dPickeFechaHoraInicio.Name = "dPickeFechaHoraInicio";
            this.dPickeFechaHoraInicio.Size = new System.Drawing.Size(129, 22);
            this.dPickeFechaHoraInicio.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(159, 43);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 22);
            this.textBox1.TabIndex = 10;
            // 
            // dPickerFechaHoraFin
            // 
            this.dPickerFechaHoraFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dPickerFechaHoraFin.Location = new System.Drawing.Point(237, 16);
            this.dPickerFechaHoraFin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dPickerFechaHoraFin.Name = "dPickerFechaHoraFin";
            this.dPickerFechaHoraFin.Size = new System.Drawing.Size(143, 22);
            this.dPickerFechaHoraFin.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(827, 4);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Doble Click para ver Detalle";
            // 
            // btnDetalle
            // 
            this.btnDetalle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDetalle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDetalle.Location = new System.Drawing.Point(815, 41);
            this.btnDetalle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDetalle.Name = "btnDetalle";
            this.btnDetalle.Size = new System.Drawing.Size(100, 28);
            this.btnDetalle.TabIndex = 2;
            this.btnDetalle.Text = "Ver &Detalle";
            this.btnDetalle.UseVisualStyleBackColor = true;
            this.btnDetalle.Click += new System.EventHandler(this.btnDetalle_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCerrar.Image = global::SAlvecoComercial10.Properties.Resources.cancel1;
            this.btnCerrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrar.Location = new System.Drawing.Point(932, 41);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(75, 28);
            this.btnCerrar.TabIndex = 1;
            this.btnCerrar.Text = "&Cerrar";
            this.btnCerrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // gBoxOpciones
            // 
            this.gBoxOpciones.Controls.Add(this.rBtnDetalleCuenta);
            this.gBoxOpciones.Controls.Add(this.rBtnDetalleCompra);
            this.gBoxOpciones.Location = new System.Drawing.Point(16, 4);
            this.gBoxOpciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxOpciones.Name = "gBoxOpciones";
            this.gBoxOpciones.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gBoxOpciones.Size = new System.Drawing.Size(416, 59);
            this.gBoxOpciones.TabIndex = 0;
            this.gBoxOpciones.TabStop = false;
            this.gBoxOpciones.Text = "Seleccione una Opción para ver un Detalle";
            // 
            // rBtnDetalleCuenta
            // 
            this.rBtnDetalleCuenta.AutoSize = true;
            this.rBtnDetalleCuenta.Location = new System.Drawing.Point(220, 23);
            this.rBtnDetalleCuenta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rBtnDetalleCuenta.Name = "rBtnDetalleCuenta";
            this.rBtnDetalleCuenta.Size = new System.Drawing.Size(142, 21);
            this.rBtnDetalleCuenta.TabIndex = 2;
            this.rBtnDetalleCuenta.Text = "Detalle de Cuenta";
            this.rBtnDetalleCuenta.UseVisualStyleBackColor = true;
            // 
            // rBtnDetalleCompra
            // 
            this.rBtnDetalleCompra.AutoSize = true;
            this.rBtnDetalleCompra.Checked = true;
            this.rBtnDetalleCompra.Location = new System.Drawing.Point(36, 23);
            this.rBtnDetalleCompra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rBtnDetalleCompra.Name = "rBtnDetalleCompra";
            this.rBtnDetalleCompra.Size = new System.Drawing.Size(146, 21);
            this.rBtnDetalleCompra.TabIndex = 1;
            this.rBtnDetalleCompra.TabStop = true;
            this.rBtnDetalleCompra.Text = "Detalle de Compra";
            this.rBtnDetalleCompra.UseVisualStyleBackColor = true;
            this.rBtnDetalleCompra.CheckedChanged += new System.EventHandler(this.rBtnDetalleCompra_CheckedChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DatosUsuario";
            this.dataGridViewTextBoxColumn1.HeaderText = "Usuario";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 74;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NumeroCompraProducto";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nro Compra";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 89;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NombreRazonSocial";
            this.dataGridViewTextBoxColumn3.FillWeight = 200F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Proveedor";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 84;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Fecha";
            this.dataGridViewTextBoxColumn4.FillWeight = 70F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Fecha Compra";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 103;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NumeroCuentaPorPagar";
            this.dataGridViewTextBoxColumn5.FillWeight = 70F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Nro Cuenta Por Pagar";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            this.dataGridViewTextBoxColumn5.Width = 112;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "TipoCliente";
            this.dataGridViewTextBoxColumn6.FillWeight = 200F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Tipo Cliente";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            this.dataGridViewTextBoxColumn6.Width = 90;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "NombreRepresentante";
            this.dataGridViewTextBoxColumn7.FillWeight = 200F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Nombre Representante";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 146;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Monto";
            this.dataGridViewTextBoxColumn8.HeaderText = "Monto de Compra";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 120;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "NombreMoneda";
            this.dataGridViewTextBoxColumn9.HeaderText = "Nombre Moneda";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 113;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Observaciones";
            this.dataGridViewTextBoxColumn10.HeaderText = "Observaciones";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "DatosUsuario";
            this.dataGridViewTextBoxColumn11.HeaderText = "Usuariio";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 77;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "NumeroCompraProducto";
            this.dataGridViewTextBoxColumn12.FillWeight = 70F;
            this.dataGridViewTextBoxColumn12.HeaderText = "Nro Compra";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "NombreRazonSocial";
            this.dataGridViewTextBoxColumn13.FillWeight = 200F;
            this.dataGridViewTextBoxColumn13.HeaderText = "Proveedor";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Fecha";
            this.dataGridViewTextBoxColumn14.FillWeight = 70F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Fecha de Compra";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 119;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "NumeroCuentaPorCobrar";
            this.dataGridViewTextBoxColumn15.FillWeight = 80F;
            this.dataGridViewTextBoxColumn15.HeaderText = "Nro Cuenta Por Cobrar";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 116;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn16.DataPropertyName = "MontoCuentaPorCobrar";
            this.dataGridViewTextBoxColumn16.FillWeight = 80F;
            this.dataGridViewTextBoxColumn16.HeaderText = "Monto Por Cobrar";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 139;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "NombreMoneda";
            this.dataGridViewTextBoxColumn17.FillWeight = 10090F;
            this.dataGridViewTextBoxColumn17.HeaderText = "Moneda";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 77;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Observaciones";
            this.dataGridViewTextBoxColumn18.FillWeight = 80F;
            this.dataGridViewTextBoxColumn18.HeaderText = "Observaciones";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "MontoTotalCompra";
            this.dataGridViewTextBoxColumn19.FillWeight = 80F;
            this.dataGridViewTextBoxColumn19.HeaderText = "T. Compra";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 81;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "MontoCuentaPorCobrar";
            this.dataGridViewTextBoxColumn20.FillWeight = 80F;
            this.dataGridViewTextBoxColumn20.HeaderText = "T. Cuenta";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 79;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "MontoPagado";
            this.dataGridViewTextBoxColumn21.FillWeight = 10090F;
            this.dataGridViewTextBoxColumn21.HeaderText = "T. Cobrado";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 85;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.DataPropertyName = "MontoDiferencia";
            this.dataGridViewTextBoxColumn22.FillWeight = 10090F;
            this.dataGridViewTextBoxColumn22.HeaderText = "T. Diferencia";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // DGCDatosUsuario2
            // 
            this.DGCDatosUsuario2.DataPropertyName = "DatosUsuario";
            this.DGCDatosUsuario2.HeaderText = "Usuariio";
            this.DGCDatosUsuario2.Name = "DGCDatosUsuario2";
            this.DGCDatosUsuario2.ReadOnly = true;
            this.DGCDatosUsuario2.Visible = false;
            this.DGCDatosUsuario2.Width = 70;
            // 
            // DGCNumeroCompraProducto2
            // 
            this.DGCNumeroCompraProducto2.DataPropertyName = "NumeroVentaProducto";
            this.DGCNumeroCompraProducto2.FillWeight = 70F;
            this.DGCNumeroCompraProducto2.HeaderText = "Nro Compra";
            this.DGCNumeroCompraProducto2.Name = "DGCNumeroCompraProducto2";
            this.DGCNumeroCompraProducto2.ReadOnly = true;
            this.DGCNumeroCompraProducto2.Width = 88;
            // 
            // DGCFecha2
            // 
            this.DGCFecha2.DataPropertyName = "FechaHoraVenta";
            this.DGCFecha2.HeaderText = "Fecha de Compra";
            this.DGCFecha2.Name = "DGCFecha2";
            this.DGCFecha2.ReadOnly = true;
            this.DGCFecha2.Width = 116;
            // 
            // DGCNumeroCuentaPorCobrar
            // 
            this.DGCNumeroCuentaPorCobrar.DataPropertyName = "NumeroCuentaPorCobrar";
            this.DGCNumeroCuentaPorCobrar.FillWeight = 80F;
            this.DGCNumeroCuentaPorCobrar.HeaderText = "Nro Cuenta Por Cobrar";
            this.DGCNumeroCuentaPorCobrar.Name = "DGCNumeroCuentaPorCobrar";
            this.DGCNumeroCuentaPorCobrar.ReadOnly = true;
            this.DGCNumeroCuentaPorCobrar.Width = 139;
            // 
            // DGCMontoTotalCompra2
            // 
            this.DGCMontoTotalCompra2.DataPropertyName = "MontoTotalVenta";
            this.DGCMontoTotalCompra2.HeaderText = "T. Venta";
            this.DGCMontoTotalCompra2.Name = "DGCMontoTotalCompra2";
            this.DGCMontoTotalCompra2.Width = 81;
            // 
            // DGCMontoCuentaPorCobrar
            // 
            this.DGCMontoCuentaPorCobrar.DataPropertyName = "MontoCuentaPorCobrar";
            this.DGCMontoCuentaPorCobrar.FillWeight = 80F;
            this.DGCMontoCuentaPorCobrar.HeaderText = "T. Cuenta";
            this.DGCMontoCuentaPorCobrar.Name = "DGCMontoCuentaPorCobrar";
            this.DGCMontoCuentaPorCobrar.ReadOnly = true;
            this.DGCMontoCuentaPorCobrar.Width = 79;
            // 
            // DGCMontoPagado2
            // 
            this.DGCMontoPagado2.DataPropertyName = "MontoPagado";
            this.DGCMontoPagado2.HeaderText = "T. Cobrado";
            this.DGCMontoPagado2.Name = "DGCMontoPagado2";
            this.DGCMontoPagado2.Width = 85;
            // 
            // DGCMontoDiferencia2
            // 
            this.DGCMontoDiferencia2.DataPropertyName = "MontoDiferencia";
            this.DGCMontoDiferencia2.HeaderText = "Saldo";
            this.DGCMontoDiferencia2.Name = "DGCMontoDiferencia2";
            this.DGCMontoDiferencia2.Width = 93;
            // 
            // DGCNombreMoneda2
            // 
            this.DGCNombreMoneda2.DataPropertyName = "NombreMoneda";
            this.DGCNombreMoneda2.FillWeight = 10090F;
            this.DGCNombreMoneda2.HeaderText = "Moneda";
            this.DGCNombreMoneda2.Name = "DGCNombreMoneda2";
            this.DGCNombreMoneda2.ReadOnly = true;
            this.DGCNombreMoneda2.Width = 71;
            // 
            // DGCObservaciones2
            // 
            this.DGCObservaciones2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DGCObservaciones2.DataPropertyName = "Observaciones";
            this.DGCObservaciones2.HeaderText = "Observaciones";
            this.DGCObservaciones2.Name = "DGCObservaciones2";
            this.DGCObservaciones2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn23.DataPropertyName = "NombreMoneda";
            this.dataGridViewTextBoxColumn23.FillWeight = 10090F;
            this.dataGridViewTextBoxColumn23.HeaderText = "Moneda";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Observaciones";
            this.dataGridViewTextBoxColumn24.HeaderText = "Observaciones";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // DGCDatosUsuario
            // 
            this.DGCDatosUsuario.DataPropertyName = "DatosUsuario";
            this.DGCDatosUsuario.HeaderText = "Usuario";
            this.DGCDatosUsuario.Name = "DGCDatosUsuario";
            this.DGCDatosUsuario.ReadOnly = true;
            this.DGCDatosUsuario.Visible = false;
            this.DGCDatosUsuario.Width = 74;
            // 
            // DGCNumeroCompraProducto
            // 
            this.DGCNumeroCompraProducto.DataPropertyName = "NumeroCompraProducto";
            this.DGCNumeroCompraProducto.HeaderText = "Nro Compra";
            this.DGCNumeroCompraProducto.Name = "DGCNumeroCompraProducto";
            this.DGCNumeroCompraProducto.ReadOnly = true;
            this.DGCNumeroCompraProducto.Width = 84;
            // 
            // DGCNombreRazonSocial
            // 
            this.DGCNombreRazonSocial.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.DGCNombreRazonSocial.DataPropertyName = "NombreRazonSocial";
            this.DGCNombreRazonSocial.FillWeight = 200F;
            this.DGCNombreRazonSocial.HeaderText = "Proveedor";
            this.DGCNombreRazonSocial.Name = "DGCNombreRazonSocial";
            this.DGCNombreRazonSocial.ReadOnly = true;
            this.DGCNombreRazonSocial.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DGCNombreRazonSocial.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.DGCNombreRazonSocial.Width = 97;
            // 
            // DGCFecha
            // 
            this.DGCFecha.DataPropertyName = "Fecha";
            this.DGCFecha.HeaderText = "Fecha Compra";
            this.DGCFecha.Name = "DGCFecha";
            this.DGCFecha.ReadOnly = true;
            this.DGCFecha.Width = 84;
            // 
            // DGCNumeroCuentaPorPagar
            // 
            this.DGCNumeroCuentaPorPagar.DataPropertyName = "NumeroCuentaPorPagar";
            this.DGCNumeroCuentaPorPagar.FillWeight = 70F;
            this.DGCNumeroCuentaPorPagar.HeaderText = "Nro Cuenta";
            this.DGCNumeroCuentaPorPagar.Name = "DGCNumeroCuentaPorPagar";
            this.DGCNumeroCuentaPorPagar.ReadOnly = true;
            this.DGCNumeroCuentaPorPagar.Width = 59;
            // 
            // DGCTipoCliente
            // 
            this.DGCTipoCliente.DataPropertyName = "TipoCliente";
            this.DGCTipoCliente.HeaderText = "Tipo Cliente";
            this.DGCTipoCliente.Name = "DGCTipoCliente";
            this.DGCTipoCliente.ReadOnly = true;
            this.DGCTipoCliente.Visible = false;
            this.DGCTipoCliente.Width = 90;
            // 
            // DGCNombreRepresentante
            // 
            this.DGCNombreRepresentante.DataPropertyName = "NombreRepresentante";
            this.DGCNombreRepresentante.FillWeight = 200F;
            this.DGCNombreRepresentante.HeaderText = "Nombre Representante";
            this.DGCNombreRepresentante.Name = "DGCNombreRepresentante";
            this.DGCNombreRepresentante.ReadOnly = true;
            this.DGCNombreRepresentante.Visible = false;
            this.DGCNombreRepresentante.Width = 146;
            // 
            // DGCMontoTotalCompra
            // 
            this.DGCMontoTotalCompra.DataPropertyName = "MontoTotalCompra";
            this.DGCMontoTotalCompra.HeaderText = "T. Compra";
            this.DGCMontoTotalCompra.Name = "DGCMontoTotalCompra";
            // 
            // DGCMonto
            // 
            this.DGCMonto.DataPropertyName = "MontoCuentaPorPagar";
            this.DGCMonto.HeaderText = "T. Cuenta";
            this.DGCMonto.Name = "DGCMonto";
            this.DGCMonto.ReadOnly = true;
            // 
            // DGCMontoPagado
            // 
            this.DGCMontoPagado.DataPropertyName = "MontoPagado";
            this.DGCMontoPagado.HeaderText = "T. Pagado";
            this.DGCMontoPagado.Name = "DGCMontoPagado";
            // 
            // DGCMontoDiferencia
            // 
            this.DGCMontoDiferencia.DataPropertyName = "MontoDiferencia";
            this.DGCMontoDiferencia.HeaderText = "Saldo";
            this.DGCMontoDiferencia.Name = "DGCMontoDiferencia";
            // 
            // DGCNombreMoneda
            // 
            this.DGCNombreMoneda.DataPropertyName = "NombreMoneda";
            this.DGCNombreMoneda.HeaderText = "Nombre Moneda";
            this.DGCNombreMoneda.Name = "DGCNombreMoneda";
            this.DGCNombreMoneda.ReadOnly = true;
            this.DGCNombreMoneda.Width = 84;
            // 
            // DGCObservaciones
            // 
            this.DGCObservaciones.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DGCObservaciones.DataPropertyName = "Observaciones";
            this.DGCObservaciones.HeaderText = "Observaciones";
            this.DGCObservaciones.Name = "DGCObservaciones";
            this.DGCObservaciones.ReadOnly = true;
            // 
            // FTransaccionesCuentasPorPagarCobrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.CancelButton = this.btnCerrar;
            this.ClientSize = new System.Drawing.Size(1028, 598);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.pnlInferiorBotones);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FTransaccionesCuentasPorPagarCobrar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transacciones Pendientes por Compras";
            this.Load += new System.EventHandler(this.FComprasProductosCuentasPorPagar_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGVCuentasPorPagar)).EndInit();
            this.pnlResumenteCuentasPorPagar.ResumeLayout(false);
            this.pnlResumenteCuentasPorPagar.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGVCuentasPorCobrar)).EndInit();
            this.pnlResumenCuentasPorCobrar.ResumeLayout(false);
            this.pnlResumenCuentasPorCobrar.PerformLayout();
            this.pnlInferiorBotones.ResumeLayout(false);
            this.pnlInferiorBotones.PerformLayout();
            this.gBoxFiltrado.ResumeLayout(false);
            this.gBoxFiltrado.PerformLayout();
            this.gBoxOpciones.ResumeLayout(false);
            this.gBoxOpciones.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel pnlInferiorBotones;
        private System.Windows.Forms.DataGridView dtGVCuentasPorPagar;
        private System.Windows.Forms.DataGridView dtGVCuentasPorCobrar;
        private System.Windows.Forms.Button btnDetalle;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.GroupBox gBoxOpciones;
        private System.Windows.Forms.RadioButton rBtnDetalleCuenta;
        private System.Windows.Forms.RadioButton rBtnDetalleCompra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.Panel pnlResumenCuentasPorCobrar;
        private System.Windows.Forms.TextBox txtBoxTCompraCC;
        private System.Windows.Forms.TextBox txtBoxTCuentaCC;
        private System.Windows.Forms.TextBox txtBoxTCobradoCC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxTDiferenciaCC;
        private System.Windows.Forms.Button btnFiltrar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.Panel pnlResumenteCuentasPorPagar;
        private System.Windows.Forms.TextBox txtBoxTCompraCP;
        private System.Windows.Forms.TextBox txtBoxTCuentaCP;
        private System.Windows.Forms.TextBox txtBoxTPagadoCP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxTDiferenciaCP;
        private System.Windows.Forms.GroupBox gBoxFiltrado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkListartodos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dPickeFechaHoraInicio;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DateTimePicker dPickerFechaHoraFin;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCDatosUsuario2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNumeroCompraProducto2;
        private System.Windows.Forms.DataGridViewComboBoxColumn DGCNombreRazonSocial2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCFecha2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNumeroCuentaPorCobrar;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoTotalCompra2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoCuentaPorCobrar;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoPagado2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoDiferencia2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNombreMoneda2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCObservaciones2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCDatosUsuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNumeroCompraProducto;
        private System.Windows.Forms.DataGridViewComboBoxColumn DGCNombreRazonSocial;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCFecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNumeroCuentaPorPagar;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCTipoCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNombreRepresentante;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoTotalCompra;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMonto;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoPagado;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCMontoDiferencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCNombreMoneda;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGCObservaciones;
    }
}